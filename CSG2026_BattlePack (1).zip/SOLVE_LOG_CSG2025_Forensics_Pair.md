# SOLVE LOG — CSG2025 Forensics Pair: memdump.zip + evidence.zip

**Status: BOTH SOLVED. Cheatsheet chains battle-tested and validated.**

---

## CHALLENGE A — memdump.zip (5 GB raw memory dump)

### Intake / Triage (LOW-RAM technique — the box only had 3 GB RAM!)

```bash
# 0) The zip is ZIP64 + DEFLATE64 — standard unzip FAILS ("End-of-central-directory not found")
#    Trick: pip install zipfile-deflate64 (needs python3.13) then stdlib zipfile just works
pip install --break-system-packages zipfile-deflate64 inflate64
python3.13 extract_memdump.py          # scripts/forensics_kit/extract_memdump.py
# -> memdump.mem, 5,368,709,120 bytes (5 GB)

# 1) DO NOT load volatility3 first (5 GB dump vs 3 GB RAM = OOM).
#    GREP FIRST — the CTF way. Flag format scan on raw bytes:
rg -a -o "CSG_FLAG\{[^}]{0,200}" memdump.mem | sort -u
rg -a -o "C\x00S\x00G\x00_\x00F\x00L\x00A\x00G\x00\{.{0,200}" memdump.mem   # UTF-16LE form

# 2) Full string carve (handles the UTF-16LE copy properly):
python3 carve_hint_flag.py
```

### FLAG (memdump challenge)
```
CSG_FLAG{The Flag can be found in a file created at 2025-09-10 08:18:20.0630481}
```

### Artifacts recovered
- User: **tsshimizu**, Desktop path `C:\Users\tsshimizu\Desktop\Tor Browser\0001|0005|0010\CSG2025_Forensic_Challenge.exe`
- Malware: .NET 8 assembly `CSG2025_Forensic_Challenge` (same family as the combined challenge),
  methods `<Main>, Deobfuscate, AdvancedEncode, AdvancedDecode, RemoteShell, ExecuteCommand`,
  crypto class `CSG2025_FC_Crypto`, static field `flag_string`
- C2 port seen in `<Main>` IL: **54321**, heartbeat JSONs in GC heap
  (`{"$type":"heartbeatResponse","requestTime":...}`)
- Author's browser artifacts (Google search "mft3csv"), .NET SDK 8.0.414 installed

### Key lesson encoded in kit
- **Grep-first memory forensics beats vol3 when RAM-limited.** vol3 still gets installed for
  process/network artifacts, but flag strings + UTF-16LE carve finds the money in minutes.
- deflate64 zip: `pip install zipfile-deflate64` + `import zipfile_deflate64` (side-effect import!) —
  this exact gotcha cost us 2 iterations; documented forever now.

---

## CHALLENGE B — evidence.zip (NTFS artifacts: $MFT 572 MB + $J 34 MB + 12 prefetch)

### Step 1 — timestamp hunt in $MFT (the hint from Challenge A)

```bash
python3 mft_triage.py '$MFT' --find-created "2025-09-10 08:18:20.0630481" --tz-hours 8 --window 1.5
```

**HIT (7.8 s scan of 584,807 records):**

| Record | File | Created (UTC) |
|---|---|---|
| 252216 | dir `0010` (parent 56521) | 2025-09-10 08:18:19.635231 |
| 252217 | CSG2025_Forensic_Challenge.deps.json (resident 470 B) | 08:18:19.635231 |
| 252218 | CSG2025_Forensic_Challenge.dll (nonresident 9,728 B) | 08:18:19.650252 |
| **252219** | **CSG2025_Forensic_Challenge.exe (nonresident 138,752 B)** | **08:18:20.063048** ← EXACT hint |
| 252220 | CSG2025_Forensic_Challenge.pdb (nonresident 12,628 B) | 08:18:20.125996 |
| 252221 | CSG2025_Forensic_Challenge.runtimeconfig.json (resident 340 B) | 08:18:20.141010 |

Timezone note: hint quoted UTC (08:18); zip local times were UTC+8 (16:xx). `--tz-hours` tests both.

### Step 2 — resident-data grep across the WHOLE $MFT

```bash
python3 mft_triage.py '$MFT' --grep-data "CSG_FLAG|flag\{" --limit 30
```

**HIT — record 252238 = `FLAG.txt` (parent 93362, seq=4, in-use):**
- $DATA resident **49 bytes**: `CSG_FLAG{The Flag can be found in a file created ` (truncated mid-write!)
- SI created 08:44:40.672498, modified 08:45:14.665374
- Full 82-char flag confirmed from memory dump — FLAG.txt is the author's draft of it.

### Step 3 — UsnJrnl story ($J, 256,141 USN records parsed)

```bash
python3 usnjrnl_triage.py '$J' --name flag
python3 usnjrnl_triage.py '$J' --rec 252238
```

Timeline reconstructed:
- 08:44:40.672 — FLAG.txt FILE_CREATE (rec 252235, then deleted/recreated)
- 08:44:40.719 — FLAG.txt.lnk created (rec 252237, in Recent shortcuts)
- 08:44:40.797 — FLAG.txt recreated (rec 252238 — the surviving record, seq bump 3→4)
- 08:45:14.665 — FLAG.txt DATA_EXTEND + CLOSE (final 49 bytes)

### Step 4 — exe content recovery path (cross-challenge)
- exe runs at LCN 7,397,845 — **outside the $MFT file**, so content must come from memory:
  `mft_meta.py` parses #~ tables → 12 MethodDefs (Main/Deobfuscate/AdvancedEncode/AdvancedDecode/
  RemoteShell/ExecuteCommand) → `il_extract.py` brute-forces module base **0x15ef8000**
  (meta_rva 0x2650) → IL extracted, dncil disasm.
- All 12 in-memory copies of the assembly have #US heaps paged out (reused by JIT code / MFT
  cache pages) — documented dead end, avoid wasting comp time on it.
- 12 BSJB copies = 12 prefetch executions confirmed.

### Prefetch correlation
12 × `CSG2025_FORENSIC_CHALLENGE.EX-*.pf` — the exe executed 12 times (matches 12 BSJB copies).

---

## VERDICT

| Challenge | Flag / Answer | Where it lives |
|---|---|---|
| memdump.zip | `CSG_FLAG{The Flag can be found in a file created at 2025-09-10 08:18:20.0630481}` | UTF-16LE in GC heap + ASCII copies |
| evidence.zip | Same string (self-referential narrative flag: "the file" = CSG2025_Forensic_Challenge.exe, found via $MFT timestamp hunt) | FLAG.txt resident $DATA (49 B draft) + full string in memory |

## Scripts validated by this solve (now in forensics_kit/)
- `extract_memdump.py` — deflate64 zip extraction
- `mft_triage.py` — MFT record parser: --find-created / --name-substr / --parent / --rec /
  --extract / --show-runs / --grep-data / --deleted / --stats
- `usnjrnl_triage.py` — $J parser: --name / --rec / --time / --reason
- `carve_hint_flag.py`, `gc_sweep.py`, `utf16_sweep.py` — memory string carving
- `mft_meta.py`, `il_extract.py`, `carve_assembly.py`, `dump_us_heap2.py`,
  `unmap_memory_pe.py` — .NET assembly recovery from raw dumps
