#!/usr/bin/env python3
"""
aes_key_hunt.py — CBC key hunt: for candidate key K, compute p2 = D(C2) ^ C1.
If the key is right, p2 is printable regardless of the IV.
Scans: 32B windows (AES-256) and 16B windows (AES-128) of any binary file(s).
Usage: python3 aes_key_hunt.py ciphertext.bin file1 [file2 ...] [--step N]
"""
import sys, base64, argparse
from Crypto.Cipher import AES

CT = base64.b64decode("1KeGOcMvvKpPbxrNRdyqJmSGh3j+ZCvIT5RKk6lTBkSGBYSYrX7dy3Q/E8wVuQAXNFMs978T1A4qyx7EeX9fvg==")
C1, C2, C3, C4 = CT[0:16], CT[16:32], CT[32:48], CT[48:64]

def printable_ratio(b):
    return sum(1 for x in b if 32 <= x < 127 or x in (9, 10, 13)) / len(b)

def check_key(k):
    """Return score of CBC middle blocks for this key (IV-independent).
    P_{i+1} = D(C_{i+1}) ^ C_i — correct for any IV if key is right.
    LESSON (CSG2025): the winning key was AES-192 (24B) — scan 16/24/32!"""
    if len(k) not in (16, 24, 32):
        return 0.0, []
    ecb = AES.new(k, AES.MODE_ECB)
    blocks = [CT[i:i+16] for i in range(0, len(CT) - len(CT) % 16, 16)]
    plains = []
    for i in range(1, len(blocks)):
        d = ecb.decrypt(blocks[i])
        p = bytes(a ^ b for a, b in zip(d, blocks[i-1]))
        plains.append(p)
    # score = fraction of blocks that are mostly printable (PKCS7 pad block is NOT)
    good = sum(1 for p in plains if printable_ratio(p) >= 0.9)
    return (good / len(plains)) if plains else 0.0, plains

def hunt(data, klen, step, label, threshold=0.5):
    assert klen in (16, 24, 32)
    hits = []
    n = len(data) - klen
    for i in range(0, n, step):
        s, plains = check_key(data[i:i+klen])
        if s >= threshold:
            hits.append((i, s, p2, p3, p4))
            print(f"[!!!] {label} offset {i:#x} score={s:.2f}")
            for p in plains: print("      P:", p)
            print(f"      p2={p2!r}")
            print(f"      p3={p3!r}")
            print(f"      p4={p4!r}")
            if len(hits) > 20: break
    return hits

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--step", type=int, default=1)
    a = ap.parse_args()
    for f in a.files:
        data = open(f, "rb").read()
        print(f"[*] {f}: {len(data):,}B — AES key hunt 16/24/32 (step={a.step})")
        hunt(data, 32, a.step, "k32")
        hunt(data, 24, a.step, "k24")   # AES-192 — missed this in CSG2025 first pass!
        hunt(data, 16, a.step, "k16")
    print("[*] done")
