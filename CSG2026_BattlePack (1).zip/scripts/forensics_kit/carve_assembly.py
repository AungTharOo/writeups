#!/usr/bin/env python3
"""
carve_assembly.py - find .NET assemblies (BSJB metadata) in a raw memory dump,
match by name in #Strings heap, and carve the PE image around them.
"""
import mmap, struct, sys, re

DUMP = "/home/z/my-project/challenges/memdump.mem"
WANT = sys.argv[1] if len(sys.argv) > 1 else "CSG2025_Forensic_Challenge"
OUT = "/home/z/my-project/challenges"

def parse_bsjb(mm, off):
    """Parse .NET metadata root at off. Returns (version_str, streams dict) or None."""
    try:
        sig = mm[off:off + 4]
        if sig != b"BSJB":
            return None
        major, minor, _res, vlen = struct.unpack_from("<HHII", mm, off + 4)
        if vlen > 256:
            return None
        version = mm[off + 16: off + 16 + vlen].rstrip(b"\x00").decode("latin-1", "replace")
        p = off + 16 + vlen
        mdflags, nstreams = struct.unpack_from("<HH", mm, p)
        p += 4
        streams = {}
        for _ in range(nstreams):
            so, ssize = struct.unpack_from("<II", mm, p)
            p += 8
            name = b""
            while mm[p:p + 1] not in (b"\x00",):
                name += mm[p:p + 1]
                p += 1
            p += 1
            p = (p + 3) & ~3  # align 4
            if len(name) > 16:
                return None
            streams[name.decode("latin-1")] = (off + so, ssize)
        return version, streams
    except Exception:
        return None

def main():
    f = open(DUMP, "rb")
    mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
    pos = 0
    hits = 0
    while True:
        idx = mm.find(b"BSJB", pos)
        if idx < 0:
            break
        pos = idx + 4
        md = parse_bsjb(mm, idx)
        if not md:
            continue
        version, streams = md
        ss = streams.get("#Strings")
        us = streams.get("#US")
        if not ss:
            continue
        soff, ssize = ss
        blob = mm[soff:soff + min(ssize, 1 << 22)]
        if WANT.encode() in blob:
            hits += 1
            info = f"@0x{idx:x} ver={version} streams={list(streams.keys())} strsize={ssize} ussize={us[1] if us else 0}"
            print(info)
            # try carve PE: search back for MZ with PE header
            base = None
            start = max(0, idx - (8 << 20))
            m = mm.rfind(b"MZ", start, idx)
            while m > 0:
                e_lfanew = struct.unpack_from("<I", mm, m + 0x3C)[0] if m + 0x40 < mm.size() else 0
                if 0x40 <= e_lfanew <= 0x400 and mm[m + e_lfanew: m + e_lfanew + 4] == b"PE\x00\x00":
                    base = m
                    break
                m = mm.rfind(b"MZ", start, m)
            print(f"   PE base candidate: 0x{base:x}" if base else "   no PE base found nearby")
            if base:
                # dump 4MB after base (section-aligned in-memory image)
                out = f"{OUT}/carved_{WANT}_{base:x}.bin"
                size = 2 << 20
                with open(out, "wb") as o:
                    o.write(mm[base:base + size])
                print(f"   carved -> {out} ({size} bytes)")
        if hits >= 12:
            break
    print(f"total matching assemblies: {hits}")

if __name__ == "__main__":
    main()
