#!/usr/bin/env python3
"""
vol_triage.py — Automated volatility3 triage runner: executes the essential
plugin sequence on a memory image and greps for flags/secrets.
Tested against Windows minidumps + raw memory images (vol 3.x).

Usage:
  python3 vol_triage.py dump.dmp                 # full triage
  python3 vol_triage.py dump.dmp --quick         # top 6 plugins only
  python3 vol_triage.py dump.dmp --dump 0x1a2b3  # dump file at virtaddr
Note: on the comp Kali box use the real `vol`/`vol.py` — this script is a
wrapper that just runs the right sequence for you.
"""
import argparse, subprocess, sys, os, re

PLUGINS_FULL = [
    "windows.info", "windows.pslist", "windows.psscan", "windows.cmdline",
    "windows.filescan", "windows.registry.hivelist", "windows.hashdump",
    "windows.netscan", "windows.malfind", "windows.dlllist",
    "windows.registry.print", "windows.evtxscan", "windows.ipt",
]
QUICK = ["windows.info", "windows.pslist", "windows.cmdline", "windows.psscan",
         "windows.filescan", "windows.malfind"]
INTERESTING = re.compile(rb"CSG_FLAG\{[^}]*\}|flag\{[^}]*\}|passw|secret|\.kdbx|\.zip|c:\\\\users", re.I)

def find_vol():
    for v in ("vol", "vol.py", "volatility3", "python3 -m volatility3"):
        try:
            subprocess.run(v.split()[:1] + ["--help"] if v != "python3 -m volatility3"
                           else ["python3", "-m", "volatility3", "--help"],
                           capture_output=True, timeout=30)
            return v
        except Exception:
            continue
    return None

def run(vol, image, plugin, extra=None):
    cmd = (vol.split() if " " in vol else [vol]) + ["-f", image, plugin] + (extra or [])
    print(f"\n===== {plugin} =====")
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=600)
        out = p.stdout + p.stderr
        sys.stdout.write(out.decode(errors="replace"))
        for m in INTERESTING.finditer(out):
            print(f"[!!!] INTERESTING: {m.group(0)!r}")
        return out
    except subprocess.TimeoutExpired:
        print("[!] timeout"); return b""

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("image"); ap.add_argument("--quick", action="store_true")
    ap.add_argument("--dump"); ap.add_argument("--save-dir", default="vol_out")
    a = ap.parse_args()
    vol = find_vol()
    if not vol:
        sys.exit("[!] volatility3 not found in PATH (install: pip install volatility3)")
    os.makedirs(a.save_dir, exist_ok=True)
    plugins = QUICK if a.quick else PLUGINS_FULL
    for pl in plugins:
        extra = ["--pid", a.dump] if a.dump and "pslist" in pl else None
        out = run(vol, a.image, pl, extra)
        if "filescan" in pl:
            with open(os.path.join(a.save_dir, "filescan.txt"), "wb") as f:
                f.write(out)
        if a.dump and "dumpfiles" in pl:
            run(vol, a.image, "windows.dumpfiles", ["--virtaddr", a.dump])
    print("\n[+] triage complete; outputs in", a.save_dir)
