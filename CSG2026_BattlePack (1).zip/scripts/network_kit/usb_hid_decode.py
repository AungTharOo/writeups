#!/usr/bin/env python3
"""
usb_hid_decode.py — Decode USB HID keyboard captures (usb.capdata / hid-data)
into typed text. Handles both 8-byte boot protocol frames and 4/8-byte variants.

Usage:
  tshark -r capture.pcap -T fields -e usb.capdata | grep -v '^$' > hid.txt
  python3 usb_hid_decode.py hid.txt
  # or pipe directly:
  tshark -r cap.pcap -T fields -e usb.capdata | python3 usb_hid_decode.py -
"""
import sys, re

# HID usage ID -> char (US layout), with shift variants
MAP = {
    0x04:('a','A'),0x05:('b','B'),0x06:('c','C'),0x07:('d','D'),0x08:('e','E'),
    0x09:('f','F'),0x0a:('g','G'),0x0b:('h','H'),0x0c:('i','I'),0x0d:('j','J'),
    0x0e:('k','K'),0x0f:('l','L'),0x10:('m','M'),0x11:('n','N'),0x12:('o','O'),
    0x13:('p','P'),0x14:('q','Q'),0x15:('r','R'),0x16:('s','S'),0x17:('t','T'),
    0x18:('u','U'),0x19:('v','V'),0x1a:('w','W'),0x1b:('x','X'),0x1c:('y','Y'),
    0x1d:('z','Z'),0x1e:('1','!'),0x1f:('2','@'),0x20:('3','#'),0x21:('4','$'),
    0x22:('5','%'),0x23:('6','^'),0x24:('7','&'),0x25:('8','*'),0x26:('9','('),
    0x27:('0',')'),0x28:('\n','\n'),0x29:('[ESC]','[ESC]'),0x2a:('[BS]','[BS]'),
    0x2b:('\t','\t'),0x2c:(' ',' '),0x2d:('-','_'),0x2e:('=','+'),0x2f:('[','{'),
    0x30:(']','}'),0x31:('\\','|'),0x32:('#','~'),0x33:(';',':'),0x34:("'",'"'),
    0x35:('`','~'),0x36:(',','<'),0x37:('.','>'),0x38:('/','?'),0x39:('[CAPS]','[CAPS]'),
    0x4f:('[RIGHT]','[RIGHT]'),0x50:('[LEFT]','[LEFT]'),0x51:('[DOWN]','[DOWN]'),0x52:('[UP]','[UP]'),
    0x4c:('[DEL]','[DEL]'),0x4a:('[HOME]','[HOME]'),0x4d:('[END]','[END]'),
}

def decode(lines):
    out = []
    for raw in lines:
        raw = raw.strip().replace(":", "")
        if not raw or len(raw) < 8:
            continue
        try:
            b = bytes.fromhex(raw)
        except ValueError:
            continue
        if len(b) >= 2 and b[0] not in (0x00, 0x01, 0x02, 0x12, 0x20):
            # maybe frame lacks the modifier byte; pad
            b = b"\x00" + b
        if len(b) < 8:
            b = b + b"\x00" * (8 - len(b))
        mod = b[0]
        shift = bool(mod & 0x22)
        for usage in b[2:8]:
            if usage == 0: continue
            if usage in MAP:
                lo, hi = MAP[usage]
                out.append(hi if shift else lo)
            else:
                out.append(f"[{usage:#04x}]")
    return "".join(out)

if __name__ == "__main__":
    src = sys.stdin if len(sys.argv) < 2 or sys.argv[1] == "-" else open(sys.argv[1])
    text = decode(src.readlines())
    print(text)
    # also try to surface flag-looking content
    m = re.search(r"CSG_FLAG\{[^}]*\}|flag\{[^}]*\}", text, re.I)
    if m:
        print("\n[!!!] FLAG FOUND:", m.group(0))
