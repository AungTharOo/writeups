#!/usr/bin/env python3
"""Analyze CSG2025 challenge pack: pcapng parser + minidump header parser."""
import struct, sys, os, re

BASE = "/home/z/my-project/challenges/csg2025/csg_reversing_network_forensic_challenge"
PCAP = os.path.join(BASE, "csg_reversing_network_forensic_challenge.pcapng")
DMP  = os.path.join(BASE, "csg_reversing_network_forensic_challenge.DMP")

# ---------------- PCAPNG parse ----------------
def parse_pcapng(path):
    data = open(path, "rb").read()
    print("="*70)
    print("PCAPNG ANALYSIS  (%d bytes)" % len(data))
    print("="*70)
    off = 0
    ifaces = []
    pkts = []
    while off < len(data):
        if off + 12 > len(data): break
        btype, blen = struct.unpack_from("<II", data, off)
        endian = "<"
        if btype == 0x0A0D0D0A:  # SHB
            bom = struct.unpack_from("<I", data, off+8)[0]
            if bom == 0x1A2B3C4D:
                endian = "<"
            else:
                endian = ">"
                btype, blen = struct.unpack_from(endian+"II", data, off)
        t = btype & 0xFFFFFFFF
        if t == 0x0A0D0D0A:
            opt = data[off+12:off+blen-4]
            m = re.findall(rb"shb_hardware|shb_os|shb_userappl", opt)
            txt = opt.replace(b"\x00", b" ")
            print(f"[SHB] options: {txt[:120]}")
        elif t == 0x00000001:  # IDB
            lt = struct.unpack_from(endian+"H", data, off+8)[0]
            ifaces.append(lt)
            print(f"[IDB] linktype={lt} ({'Ethernet' if lt==1 else 'raw/other'})")
        elif t == 0x00000006:  # EPB
            cap, orig = struct.unpack_from(endian+"II", data, off+20)
            pkt = data[off+28:off+28+cap]
            pkts.append(pkt)
        elif t == 0x00000003:  # SPB
            pkt = data[off+16:off+16+ (blen-32 if blen>=32 else 0)]
            pkts.append(pkt)
        off += blen
    print(f"[+] total packets: {len(pkts)}")

    def eth_parse(pkt):
        if len(pkt) < 14: return None
        et = struct.unpack_from(">H", pkt, 12)[0]
        return et, pkt

    flows = {}
    for i, pkt in enumerate(pkts):
        r = eth_parse(pkt)
        if not r: continue
        et, p = r
        l3 = None
        if et == 0x0800 and len(p) >= 34:
            ihl = (p[14] & 0x0F) * 4
            proto = p[23]
            src = ".".join(str(b) for b in p[26:30]); dst = ".".join(str(b) for b in p[30:34])
            if proto == 6 and len(p) >= 14+ihl+20:
                sp, dp = struct.unpack_from(">HH", p, 14+ihl)
                l3 = f"TCP {src}:{sp} -> {dst}:{dp}"
                payload = p[14+ihl+ (p[14+ihl+12]>>4)*4:]
                flows.setdefault(l3, b"")
                flows[l3] += payload
                flags = p[14+ihl+13]
                l3 += f" flags={flags:#04x}"
            elif proto == 17:
                sp, dp = struct.unpack_from(">HH", p, 14+ihl)
                l3 = f"UDP {src}:{sp} -> {dst}:{dp}"
                payload = p[14+ihl+8:]
                flows.setdefault(l3, b"")
                flows[l3] += payload
            elif proto == 1:
                l3 = f"ICMP {src} -> {dst}"
                payload = p[14+ihl+8:]
                flows.setdefault(l3, b"")
                flows[l3] += payload
        if l3:
            print(f"  pkt{i:03d}: {l3} ({len(pkt)}B on wire)")
    print("\n--- Reconstructed stream payloads ---")
    for k, v in flows.items():
        print(f"\n>>> {k}  ({len(v)} bytes payload)")
        # show printable + hex
        txt = "".join(chr(b) if 32 <= b < 127 else "." for b in v)
        print("ASCII:", txt[:800])
        print("HEX  :", v[:200].hex(" "))

# ---------------- Minidump parse ----------------
STREAM_TYPES = {0:'Unused',3:'ThreadListStream',4:'ModuleListStream',5:'MemoryListStream',
6:'ExceptionStream',7:'SystemInfoStream',8:'ThreadExListStream',9:'Memory64ListStream',
10:'CommentStreamA',11:'CommentStreamW',12:'HandleDataStream',13:'FunctionTableStream',
14:'UnloadedModuleListStream',15:'MiscInfoStream',16:'MemoryInfoListStream',
17:'ThreadInfoListStream',18:'HandleOperationListStream',19:'TokenStream',22:'SystemMemoryInfoStream',
23:'ProcessVmCountersStream',24:'IptTraceStream',25:'ThreadNamesStream'}

def parse_minidump(path):
    data = open(path, "rb").read()
    print("\n" + "="*70)
    print("MINIDUMP ANALYSIS (%d bytes)" % len(data))
    print("="*70)
    sig, ver, nstreams, dir_rva, chk, ts, flags = struct.unpack_from("<4sIIIIIQ", data, 0)
    print(f"sig={sig} version={ver:#x} streams={nstreams} dir_rva={dir_rva:,} timestamp={ts}")
    for i in range(nstreams):
        st, sz, srva = struct.unpack_from("<III", data, dir_rva + i*12)
        name = STREAM_TYPES.get(st, f'Type{st}')
        print(f"  stream[{i:2d}] {name:28s} size={sz:>10,} rva={srva:>10,}")
    # SystemInfoStream (7): PROCESSOR_ARCHITECTURE + OS version
    for i in range(nstreams):
        st, sz, srva = struct.unpack_from("<III", data, dir_rva + i*12)
        if st == 7:
            arch, lvl, rev, ncpu = struct.unpack_from("<HHII", data, srva)
            maj, mnr, build = struct.unpack_from("<III", data, srva+10)
            # CSDStringRva at +24
            csd_rva = struct.unpack_from("<I", data, srva+24)[0]
            osver = ""
            if csd_rva:
                ln = struct.unpack_from("<I", data, csd_rva)[0]
                osver = data[csd_rva+4:csd_rva+4+ln].decode("utf-16-le", "replace")
            print(f"[SystemInfo] arch={arch} ver={maj}.{mnr} build={build} {osver!r}")
        if st == 4:  # ModuleListStream
            n = struct.unpack_from("<I", data, srva)[0]
            print(f"[Modules] count={n}")
            for m in range(min(n, 200)):
                base = srva + 4 + m*108
                mbase, msize, mchk, mts, name_rva = struct.unpack_from("<QIIII", data, base)
                ln = struct.unpack_from("<I", data, name_rva)[0]
                nm = data[name_rva+4:name_rva+4+ln].decode("utf-16-le","replace")
                print(f"   {mbase:#018x} {msize:>10,} {nm}")
        if st == 15:  # MiscInfo
            print(f"[MiscInfo] size={sz}")

if __name__ == "__main__":
    parse_pcapng(PCAP)
    parse_minidump(DMP)
