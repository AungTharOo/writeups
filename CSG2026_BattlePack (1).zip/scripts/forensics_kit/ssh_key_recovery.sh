#!/usr/bin/env bash
# =============================================================================
# ssh_key_recovery.sh — Memory dump -> OpenSSH session keys -> decrypt SSH pcap
# =============================================================================
# WHY THIS EXISTS (tool-hint intelligence):
#   "OpenSSH-Session-Key-Recovery" is a volatility3 PLUGIN on the approved list
#   (participant-requested, row 32: "Plugin for Volatility3"). Nobody requests a
#   niche plugin for fun -> the memory forensics challenge WILL hand you
#   (1) a memory dump of a machine running ssh/sshd, and
#   (2) an SSH pcap you cannot read...
#   ...until you pull the session keys out of RAM and feed Wireshark.
#   Source: fox-it/OpenSSH-Session-Key-Recovery (Jelle Vergeer / Fox-IT).
#
# USAGE:  ./ssh_key_recovery.sh dump.mem [capture.pcap]
# =============================================================================
DMP="${1:?usage: ./ssh_key_recovery.sh dump.mem [capture.pcap]}"
PCAP="${2:-}"
PLUGIN_DIR="/opt/tools/OpenSSH-Session-Key-Recovery/volatility3"
SYM_DIR="/opt/tools/OpenSSH-Session-Key-Recovery/volatility3/symbols"

echo "===== 0. CONTEXT: is there even SSH in this image? ====="
vol -f "$DMP" linux.pslist 2>/dev/null | grep -iE "ssh|Name" || true
vol -f "$DMP" windows.pslist 2>/dev/null | grep -iE "ssh|Name" || true
vol -f "$DMP" linux.bash 2>/dev/null | head -30   # shell history in RAM
vol -f "$DMP" linux.sockstat 2>/dev/null | grep -E "22|ssh" || true
strings -a "$DMP" | grep -aiE "SSH-2\.0-OpenSSH_[0-9.]+" | sort -u | head
#  ^ the version banner in RAM tells you OpenSSH build -> which symbol file fits

echo; echo "===== 1. RECOVER SESSION KEYS (fox-it plugin) ====="
# The table says the plugin is installed INSIDE volatility3 (linux plugins dir),
# so the plugin name is linux.openssh_sessionkeys. Fallbacks cover other layouts.
vol -f "$DMP" -s "$SYM_DIR" linux.openssh_sessionkeys 2>/dev/null \
  || vol -f "$DMP" -s "$SYM_DIR" openssh_sessionkeys 2>/dev/null \
  || vol -f "$DMP" -p "$PLUGIN_DIR" -s "$SYM_DIR" openssh_sessionkeys 2>/dev/null \
  || { echo "[!] plugin name not found — list what vol sees:"; \
       vol -h 2>/dev/null | grep -i ssh; \
       echo "    check: ls /usr/lib/python3*/dist-packages/volatility3/framework/plugins/linux/ | grep -i ssh"; }
# Output columns: Name  Pid  PPid  Arguments  Address  Cipher  Key(hex)  IV(hex)
# One row per DIRECTION — client->server and server->client keys differ. Keep both!
echo "[*] save the table:  vol -f $DMP -s $SYM_DIR linux.openssh_sessionkeys | tee ssh_keys.txt"

echo; echo "===== 2. MAP KEYS TO PCAP ENDPOINTS ====="
if [ -n "$PCAP" ]; then
  tshark -r "$PCAP" -Y "ssh" -T fields -e tcp.srcport -e ip.src -e tcp.dstport -e ip.dst 2>/dev/null \
    | sort | uniq -c | sort -rn | head
  echo "[*] port 22 side = SERVER. The plugin gives per-process keys;"
  echo "    match dump hostname/user to the client IP if several SSH sessions exist."
fi

echo; echo "===== 3. WIRESHARK DECRYPT (GUI, 4.2+) ====="
cat <<'EOF'
Edit > Preferences > Protocols > SSH > [+] one entry PER DIRECTION:
  Address 1 : <client_ip>:<port>       (e.g. 10.0.0.5:48122)
  Address 2 : <server_ip>:22
  Algorithm : exact cipher string from plugin output (e.g. aes256-ctr, aes256-gcm@openssh.com)
  Key       : Key column hex
  IV        : IV column hex
Add a SECOND entry with endpoints swapped for the other direction.
Then: the "Follow TCP Stream" on port-22 traffic shows the plaintext session
(commands, cat'ed flag files, SCP transfers). Grep it for CSG_FLAG.
EOF

echo; echo "===== 4. OFFLINE FALLBACK (no Wireshark / old version) ====="
cat <<'EOF'
- fox-it repo also ships a standalone parser (repo: pip-package/ + blog code):
    python3 ssh_protocol_parser.py  (feed pcap + keys JSON, prints session)
- manual aes-ctr decryption skeleton (python3, pycryptodome is preinstalled):
    from Crypto.Cipher import AES
    c = AES.new(bytes.fromhex(KEY), AES.MODE_CTR,
                nonce=b'', initial_value=bytes.fromhex(IV))
    plain = c.decrypt(stream_bytes_from_NEWKEYS_onwards)
  (start the ciphertext at the first byte AFTER the NEWKEYS frame per direction)
EOF
echo "[*] DUMP-side fallback if plugin fails: strings -a $DMP | grep -aiE 'aes[0-9]+-(ctr|gcm|cbc)'"
