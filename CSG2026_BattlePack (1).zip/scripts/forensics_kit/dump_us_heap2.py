#!/usr/bin/env python3
"""Seek-based #US heap dumper (low-RAM). Offsets file from: rg -a -b -o BSJB dump.mem"""
import struct, sys

DUMP = "/home/z/my-project/challenges/memdump.mem"
OFFS = "/tmp/bsjb_offsets.txt"
WANT = sys.argv[1] if len(sys.argv) > 1 else "CSG2025_Forensic_Challenge"

def read_bsjb(f, off):
    f.seek(off)
    hdr = f.read(16)
    if len(hdr) < 16 or hdr[:4] != b"BSJB":
        return None
    major, minor, _r, vlen = struct.unpack_from("<HHII", hdr, 4)
    if not (0 < vlen <= 260):
        return None
    version = f.read(vlen).rstrip(b"\x00").decode("latin-1", "replace")
    p = 16 + vlen
    rest = f.read(4 + 8 * 8 + 16 * 8)
    _mdflags, nstreams = struct.unpack_from("<HH", rest, 0)
    if not (0 < nstreams <= 8):
        return None
    q = 4
    streams = {}
    for _ in range(nstreams):
        so, ssize = struct.unpack_from("<II", rest, q)
        q += 8
        z = rest.index(b"\x00", q)
        name = rest[q:z].decode("latin-1", "replace")
        q = z + 1
        q += (-q) % 4
        streams[name] = (off + so, ssize)
    return version, streams

def decode_us_blob(blob: bytes):
    out = []
    i = 0
    while i < len(blob):
        b0 = blob[i]
        if b0 == 0:
            i += 1
            continue
        if b0 & 0x80 == 0:
            ln, skip = b0 & 0x7F, 1
        elif b0 & 0xC0 == 0x80:
            ln, skip = ((b0 & 0x3F) << 8) | blob[i + 1], 2
        else:
            ln = ((b0 & 0x1F) << 24) | (blob[i+1] << 16) | (blob[i+2] << 8) | blob[i+3]
            skip = 4
        if ln == 0:
            i += skip
            continue
        ln -= 1
        if skip + ln > len(blob) - i:
            break
        data = blob[i + skip: i + skip + ln]
        out.append(data.decode("utf-16-le", "replace"))
        i += skip + ln + 1
    return out

f = open(DUMP, "rb")
seen = {}
n = 0
for line in open(OFFS):
    off = int(line.split(":")[0])
    n += 1
    md = read_bsjb(f, off)
    if not md:
        continue
    version, streams = md
    ss = streams.get("#Strings")
    us = streams.get("#US")
    if not ss or not us:
        continue
    soff, ssize = ss
    if not (0 < ssize < (4 << 20)):
        continue
    f.seek(soff)
    sdata = f.read(ssize)
    if WANT.encode() not in sdata:
        continue
    uoff, usize = us
    if not (0 < usize < (4 << 20)):
        continue
    f.seek(uoff)
    strs = decode_us_blob(f.read(usize))
    key = tuple(strs)
    if key in seen:
        seen[key].append(off)
        continue
    seen[key] = [off]
    print(f"===== BSJB @0x{off:x} usize={usize} nstrings={len(strs)} =====")
    for s in strs:
        print(f"   {s!r}")
print(f"\nscanned {n} BSJB roots, unique heaps: {len(seen)}")
