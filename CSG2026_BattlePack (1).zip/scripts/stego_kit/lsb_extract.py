#!/usr/bin/env python3
"""
lsb_extract.py — LSB stego extractor for PNG/BMP. Tries common bit-plane
configurations (R/G/B/ARGB, MSB/LSB-first, row/col order) and reports
printable output. Complements zsteg (Ruby) for quick manual checks.

Usage:
  python3 lsb_extract.py image.png              # try all common configs
  python3 lsb_extract.py image.png -c RGB -b 1 --msb-first -o out.bin
"""
import argparse, sys, zlib

def load_png(path):
    data = open(path, "rb").read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n", "not PNG"
    off = 8; idat = b""; w = h = bd = ct = None
    while off < len(data):
        ln, typ = int.from_bytes(data[off:off+4], "big"), data[off+4:off+8]
        chunk = data[off+8:off+8+ln]
        if typ == b"IHDR":
            w, h, bd, ct = int.from_bytes(chunk[0:4],"big"), int.from_bytes(chunk[4:8],"big"), chunk[8], chunk[9]
        elif typ == b"IDAT":
            idat += chunk
        elif typ == b"IEND":
            break
        off += 12 + ln
    raw = zlib.decompress(idat)
    ch = {0:1, 2:3, 3:1, 4:2, 6:4}.get(ct)
    if ch is None or bd != 8:
        sys.exit(f"[!] unsupported PNG: bitdepth={bd} colortype={ct} (try zsteg instead)")
    stride = w * ch
    out = bytearray()
    prev = bytearray(stride)
    pos = 0
    for y in range(h):
        f = raw[pos]; pos += 1
        line = bytearray(raw[pos:pos+stride]); pos += stride
        if f == 1:
            for i in range(ch, stride): line[i] = (line[i] + line[i-ch]) & 0xFF
        elif f == 2:
            for i in range(stride): line[i] = (line[i] + prev[i]) & 0xFF
        elif f == 3:
            for i in range(stride):
                a = line[i-ch] if i >= ch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 0xFF
        elif f == 4:
            for i in range(stride):
                a = line[i-ch] if i >= ch else 0
                b = prev[i]; c = prev[i-ch] if i >= ch else 0
                p = a + b - c
                pa, pb, pc = abs(p-a), abs(p-b), abs(p-c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 0xFF
        out += line
        prev = line
    return w, h, ch, bytes(out)

def extract(px, w, h, ch, chans, bit, msb_first, order):
    idxmap = {"R":0, "G":1, "B":2, "A":ch-1 if ch == 4 else 0}
    bits = []
    if order == "row":
        for y in range(h):
            for x in range(w):
                base = (y*w + x)*ch
                for cname in chans:
                    v = px[base + idxmap[cname]]
                    bits.append((v >> bit) & 1)
    else:
        for x in range(w):
            for y in range(h):
                base = (y*w + x)*ch
                for cname in chans:
                    bits.append((px[base + idxmap[cname]] >> bit) & 1)
    out = bytearray()
    for i in range(0, len(bits) - 7, 8):
        byte = 0
        group = bits[i:i+8]
        if msb_first:
            for b in group: byte = (byte << 1) | b
        else:
            for j, b in enumerate(group): byte |= b << j
        out.append(byte)
    return bytes(out)

def score(b):
    if not b: return 0
    return sum(1 for x in b[:400] if 32 <= x < 127 or x in (9,10,13)) / min(len(b), 400)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("image"); ap.add_argument("-c", default="RGB")
    ap.add_argument("-b", "--bit", type=int)
    ap.add_argument("--msb-first", action="store_true")
    ap.add_argument("--order", choices=["row", "col"], default="row")
    ap.add_argument("-o", "--out")
    a = ap.parse_args()
    w, h, ch, px = load_png(a.image)
    print(f"[*] {w}x{h} ch={ch}")
    if a.bit is not None:
        combos = [(a.c, a.bit, a.msb_first, a.order)]
    else:
        combos = []
        for cn in ["RGB", "BGR", "R", "G", "B"] + (["ARGB"] if ch == 4 else []):
            for bt in range(8):
                for mf in (False, True):
                    combos.append((cn, bt, mf, "row"))
    results = []
    for cn, bt, mf, od in combos:
        data = extract(px, w, h, ch, cn, bt, mf, od)
        s = score(data)
        results.append((s, cn, bt, mf, od, data))
    results.sort(reverse=True, key=lambda t: t[0])
    for s, cn, bt, mf, od, data in results[:10]:
        txt = "".join(chr(b) if 32 <= b < 127 else "." for b in data[:72])
        flag = " <<< FLAG?" if b"CSG" in data[:2000] or b"flag" in data[:2000].lower() else ""
        print(f"{s:.2f} {cn:5s} bit={bt} {'msb' if mf else 'lsb'}-first {od}{flag}  {txt}")
    if a.out:
        s, cn, bt, mf, od, data = results[0]
        open(a.out, "wb").write(data)
        print(f"[+] best -> {a.out}")
