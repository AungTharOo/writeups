#!/usr/bin/env python3
"""
xor_brute.py — Single-byte + repeating-key XOR brute with printable scoring
and known-plaintext crib search. The #1 cipher in misc/crypto challenges.

Usage:
  python3 xor_brute.py file.bin                       # single-byte brute, top scores
  python3 xor_brute.py file.bin --hex                 # input is hex string
  python3 xor_brute.py file.bin --key simplekey       # decrypt with repeating key
  python3 xor_brute.py file.bin --crib CSG_FLAG       # find single-byte key by crib
"""
import argparse, sys

def pr(b):
    if not b: return 0
    return sum(1 for x in b if 32 <= x < 127 or x in (9, 10, 13)) / len(b)

def single_brute(data, top=8):
    scores = []
    for k in range(256):
        out = bytes(x ^ k for x in data)
        scores.append((pr(out), k, out))
    scores.sort(reverse=True, key=lambda t: t[0])
    return scores[:top]

def crib_search(data, crib):
    """If plaintext contains crib, key byte(s) = data[i:i+len] ^ crib (single-byte case)."""
    hits = set()
    for i in range(len(data) - len(crib) + 1):
        k = data[i] ^ crib[0]
        if all(data[i + j] ^ k == crib[j] for j in range(len(crib))):
            hits.add(k)
    return sorted(hits)

def rep_decrypt(data, key):
    return bytes(x ^ key[i % len(key)] for i, x in enumerate(data))

def show(tag, out):
    txt = "".join(chr(b) if 32 <= b < 127 else "." for b in out[:96])
    print(f"{tag} {txt}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--hex", action="store_true", help="file contains a hex string")
    ap.add_argument("--key", help="repeating-key XOR decrypt")
    ap.add_argument("--crib", help="known plaintext substring (e.g. CSG_FLAG)")
    ap.add_argument("--top", type=int, default=8)
    a = ap.parse_args()

    raw = open(a.file, "rb").read()
    if a.hex:
        raw = bytes.fromhex(raw.decode().strip())
    if a.key:
        out = rep_decrypt(raw, a.key.encode())
        show(f"[key={a.key}]", out)
        sys.exit(0)
    if a.crib:
        ks = crib_search(raw, a.crib.encode())
        for k in ks:
            out = bytes(x ^ k for x in raw)
            show(f"[crib hit k={k:#04x}]", out)
        if not ks:
            print("[-] no single-byte crib hit — try repeating key / multi-byte")
        sys.exit(0)
    print(f"[*] single-byte XOR brute on {len(raw)}B")
    for s, k, out in single_brute(raw, a.top):
        flag = " <<<" if b"CSG" in out or b"flag" in out.lower() else ""
        show(f"[{s:.2f} k={k:#04x}]{flag}", out)
