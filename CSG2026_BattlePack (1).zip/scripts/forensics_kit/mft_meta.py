#!/usr/bin/env python3
"""
mft_meta.py - minimal ECMA-335 #~ table parser for a metadata root carved from raw memory.
Then brute-force module base and extract MethodDef IL.

Usage: python3 mft_meta.py <dump> <root_addr_hex>
"""
import struct, sys

DUMP = sys.argv[1] if len(sys.argv) > 1 else "/home/z/my-project/challenges/memdump.mem"
ROOT = int(sys.argv[2], 0) if len(sys.argv) > 2 else 0x15efa650

TABLE_NAMES = {
    0x00: "Module", 0x01: "TypeRef", 0x02: "TypeDef", 0x03: "FieldPtr", 0x04: "Field",
    0x05: "MethodPtr", 0x06: "MethodDef", 0x07: "ParamPtr", 0x08: "Param",
    0x09: "InterfaceImpl", 0x0A: "MemberRef", 0x0B: "Constant", 0x0C: "CustomAttribute",
    0x0D: "StandAloneSig", 0x0E: "TypeSpec", 0x0F: "Assembly", 0x10: "AssemblyProcessor",
    0x11: "AssemblyOS", 0x12: "AssemblyRef", 0x13: "AssemblyRefProcessor",
    0x14: "AssemblyRefOS", 0x15: "File", 0x16: "ExportedType", 0x17: "ManifestResource",
    0x18: "NestedClass", 0x19: "GenericParam", 0x1A: "MethodSpec",
    0x1B: "GenericParamConstraint",
}

# coded index: (name, [table ids], tag bits)
CODED = {
    "TypeDefOrRef": (0x02, 0x01, 0x1B >> 8),  # placeholder, replaced below
}

def build_coded():
    C = {}
    C["TypeDefOrRef"] = ([0x02, 0x01, 0x1B], 2)
    C["HasConstant"] = ([0x04, 0x08, 0x17], 2)
    C["HasCustomAttribute"] = ([0x06, 0x04, 0x01, 0x02, 0x08, 0x09, 0x0A, 0x17,
                                0x14, 0x11, 0x1A, 0x1B, 0x20, 0x12, 0x15, 0x16,
                                0x00, 0x0E, 0x0F], 5)
    C["HasFieldMarshal"] = ([0x04, 0x08], 1)
    C["HasDeclSecurity"] = ([0x02, 0x06, 0x0F], 2)
    C["MemberRefParent"] = ([0x02, 0x01, 0x1A, 0x06, 0x1B], 3)
    C["HasSemantics"] = ([0x14, 0x17], 1)  # Event(0x14)?? no Event=0x14 is wrong; Event=0x14, Property=0x17
    C["MethodDefOrRef"] = ([0x06, 0x0A], 1)
    C["MemberForwarded"] = ([0x04, 0x06], 1)
    C["Implementation"] = ([0x26, 0x23, 0x1B], 2)
    C["CustomAttributeType"] = ([None, None, 0x06, 0x0A, None], 3)
    C["ResolutionScope"] = ([0x00, 0x1A, 0x23, 0x01], 2)
    C["TypeOrMethodDef"] = ([0x02, 0x06], 1)
    return C

CODED = build_coded()
# fix known tables
CODED["HasSemantics"] = ([0x14, 0x17], 1)  # Event, Property
CODED["Implementation"] = ([0x26, 0x23, 0x1B], 2)  # File, AssemblyRef, ExportedType
CODED["ResolutionScope"] = ([0x00, 0x1A, 0x23, 0x01], 2)  # Module, ModuleRef, AssemblyRef, TypeRef

def idx_size(table_id, rows):
    return 4 if table_id < len(rows) and rows[table_id] >= 0x10000 else 2

def coded_size(tables, rows):
    mx = max((rows[t] if t is not None and t < len(rows) else 0) for t in tables)
    tag_extra = 1 << CODED_TAG[0]  # not used; compute inline

def row_size(t, heap, rows):
    s = idx = lambda tid: idx_size(tid, rows)
    def ci(name):
        tables, bits = CODED[name]
        mx = max((rows[tt] if tt is not None and tt < len(rows) else 0) for tt in tables)
        return 4 if (mx >= (1 << (16 - bits))) else 2
    if t == 0x00: return 2 + s(0) + 3 * s(0x20 if False else 99)  # Module: Generation, Name, Mvid, EncId, EncBaseId (guid idx)
    return None

def parse_meta(f, root):
    f.seek(root)
    hdr = f.read(16)
    _, _, _, vlen = struct.unpack("<HHII", hdr[4:])
    version = f.read(vlen).rstrip(b"\x00").decode("latin-1")
    p = root + 16 + vlen
    f.seek(p)
    rest = f.read(0x100)
    _fl, nst = struct.unpack_from("<HH", rest, 0)
    q = 4
    streams = {}
    tbl_start = p + q
    for _ in range(nst):
        so, ssize = struct.unpack_from("<II", rest, q)
        q += 8
        z = rest.index(b"\x00", q)
        name = rest[q:z].decode("latin-1")
        q = z + 1
        rel = (p + q) - tbl_start
        q += (-rel) % 4
        streams[name] = (root + so, ssize)
    return version, streams

def parse_tables(f, troot, tsize):
    f.seek(troot)
    data = f.read(tsize)
    _res, maj, mino, heaps, _r = struct.unpack_from("<IBBBB", data, 0)
    valid, sorted_ = struct.unpack_from("<QQ", data, 8)
    sflag = heaps  # bit0 strings4, bit1 guid4, bit2 blob4
    str_sz = 4 if heaps & 1 else 2
    guid_sz = 4 if heaps & 2 else 2
    blob_sz = 4 if heaps & 4 else 2
    rows = [0] * 64
    p = 24
    for b in range(64):
        if valid & (1 << b):
            rows[b] = struct.unpack_from("<I", data, p)[0]
            p += 4
    def si(tid):
        return 4 if rows[tid] >= 0x10000 else 2
    def ci(name):
        tabs, bits = CODED[name]
        mx = 0
        for tt in tabs:
            if tt is not None and rows[tt]:
                mx = max(mx, rows[tt])
        return 4 if mx >= (1 << (16 - bits)) else 2
    sizes = {}
    for b in range(64):
        if not (valid & (1 << b)):
            continue
        if b == 0x00: sz = 2 + si(0) + guid_sz * 3
        elif b == 0x01: sz = ci("ResolutionScope") + si(0) * 2
        elif b == 0x02: sz = 4 + si(0) * 2 + ci("TypeDefOrRef") + si(0x04) + si(0x06)
        elif b == 0x03: sz = si(0x04)
        elif b == 0x04: sz = 2 + si(0) + blob_sz
        elif b == 0x05: sz = si(0x06)
        elif b == 0x06: sz = 4 + 2 + 2 + si(0) + blob_sz + si(0x08)
        elif b == 0x07: sz = si(0x08)
        elif b == 0x08: sz = 2 + 2 + si(0)
        elif b == 0x09: sz = ci("TypeDefOrRef") + si(0x02)
        elif b == 0x0A: sz = ci("MemberRefParent") + si(0) + blob_sz
        elif b == 0x0B:
            sz = 1 + 1 + ci("HasConstant") + blob_sz
        elif b == 0x0C: sz = ci("HasCustomAttribute") + ci("CustomAttributeType") + blob_sz
        elif b == 0x0D: sz = blob_sz
        elif b == 0x0E: sz = blob_sz
        elif b == 0x0F: sz = 4 + 2 + 2 + 2 + 2 + 4 + blob_sz + si(0) + si(0)
        elif b == 0x10: sz = 4 + 4
        elif b == 0x11: sz = 4 + 4 + 4
        elif b == 0x12: sz = 2 + 2 + 2 + 2 + 4 + blob_sz + si(0) + si(0) + blob_sz
        elif b == 0x13: sz = 4 + ci("ResolutionScope")
        elif b == 0x14: sz = 4 + 4 + 4 + ci("Implementation")  # AssemblyRefOS
        elif b == 0x15: sz = 4 + si(0) + blob_sz
        elif b == 0x16: sz = 4 + si(0) + si(0) + ci("Implementation") + si(0x02)
        elif b == 0x17: sz = 4 + 4 + si(0) + ci("Implementation")
        elif b == 0x18: sz = si(0x02) + si(0x02)
        elif b == 0x19: sz = 2 + 2 + ci("TypeOrMethodDef") + si(0)
        elif b == 0x1A: sz = ci("MethodDefOrRef") + blob_sz
        elif b == 0x1B: sz = si(0x19) + ci("TypeDefOrRef")
        elif b == 0x20: sz = si(0)  # UserString for fake tables - not real
        else:
            sz = None
        sizes[b] = sz
        if sz is None:
            print(f"  [!] unknown table {b:#x} rows={rows[b]} - cannot size (stop sizing after)")
            break
        p += sz * rows[b]
    return dict(rows=rows, sizes=sizes, data=data, str_sz=str_sz, blob_sz=blob_sz,
                guid_sz=guid_sz, offset_of_tables=p, valid=valid)

def table_starts(tables):
    """Data region starts after header(24) + 4*popcount(valid) row-count bytes."""
    import binascii
    nbits = bin(tables["valid"]).count("1")
    p = 24 + 4 * nbits
    starts = {}
    for b in range(64):
        if not (tables["valid"] & (1 << b)):
            continue
        starts[b] = p
        sz = tables["sizes"].get(b)
        if sz is None:
            break
        p += sz * tables["rows"][b]
    return starts

def get_methoddefs(tables):
    """Return list of (rva, name_off, implflags, flags) for MethodDef."""
    rows = tables["rows"]
    sizes = tables["sizes"]
    data = tables["data"]
    starts = table_starts(tables)
    if 0x06 not in starts:
        return [], starts
    off = starts[0x06]
    out = []
    n = rows[0x06]
    for i in range(n):
        rva, implf, flags = struct.unpack_from("<IHH", data, off)
        noff = struct.unpack_from("<" + ("I" if tables["str_sz"] == 4 else "H"), data, off + 8)[0]
        out.append((rva, noff, implf, flags))
        off += sizes[0x06]
    return out, starts

def strings_lookup(f, sroot, noff):
    f.seek(sroot + noff)
    b = f.read(64)
    return b.split(b"\x00")[0].decode("latin-1", "replace")

def main():
    f = open(DUMP, "rb")
    version, streams = parse_meta(f, ROOT)
    print(f"root=0x{ROOT:x} ver={version}")
    print("streams:", {k: (hex(v[0]), v[1]) for k, v in streams.items()})
    tro, trs = streams["#~"]
    tables = parse_tables(f, tro, trs)
    print("rows:", {TABLE_NAMES.get(b, hex(b)): tables["rows"][b]
                    for b in range(64) if tables["valid"] & (1 << b)})
    methods, starts = get_methoddefs(tables)
    sroot, ssize = streams["#Strings"]
    print(f"\nMethodDef rows={len(methods)} table@0x{starts.get(0x06, 0):x}")
    for i, (rva, noff, implf, flags) in enumerate(methods):
        nm = strings_lookup(f, sroot, noff)
        print(f"  [{i}] rva=0x{rva:x} name={nm!r}")

if __name__ == "__main__":
    main()
