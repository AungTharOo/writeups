#!/usr/bin/env python3
"""
rsa_attack.py — All-in-one RSA attack toolkit for CTF.
Order of attacks mirrors the CSG decision tree: factordb -> shared prime (gcd)
-> Wiener (small d) -> small e (Hastad / cube-root) -> close primes (Fermat).

Usage:
  python3 rsa_attack.py --n <int|hex> --e <int> --c <int|hex> [--ct-is-hex] [--pub key.pem]
  python3 rsa_attack.py --pub key.pem --c <int>          # reads n,e from PEM
  python3 rsa_attack.py --n ... --e ... --c ... --p <p>  # supply p -> full decrypt
"""
import argparse, base64, math, sys

try:
    import requests
except ImportError:
    requests = None

def to_int(s, hexmode=False):
    if s is None: return None
    return int(s, 16) if hexmode else int(s)

def i2b(x):
    return x.to_bytes((x.bit_length() + 7) // 8, "big")

def read_pubkey(path):
    from Crypto.PublicKey import RSA
    k = RSA.import_key(open(path, "rb").read())
    return k.n, k.e

def factordb(n):
    """Try factordb (network allowed for DBs? On comp: NO internet to services that
    take uploads. factordb query is a lookup; competition rules ban uploading files,
    numbers may be allowed — prefer local methods first, use factordb only if rules permit.)"""
    if requests is None:
        return None
    try:
        r = requests.get("http://factordb.com/api", params={"query": str(n)}, timeout=8)
        j = r.json()
        f = j.get("factors", [])
        if f and all(x[2] > 0 for x in f) and len(f) >= 2:
            return [int(x[0]) for x in f]
    except Exception:
        pass
    return None

def gcd_shared_prime(n1, n2):
    g = math.gcd(n1, n2)
    return g if 1 < g < min(n1, n2) else None

def wiener(n, e):
    """Continued fraction attack for small d."""
    cf, a, b, c, d = [], n, e, 1, 0
    q, r = divmod(a, b); cf.append(q)
    while r:
        a, b = b, r
        q, r = divmod(a, b); cf.append(q)
    for k in range(1, len(cf)):
        num, den = cf[k], 1
        for j in range(k - 1, -1, -1):
            num, den = cf[j] * num + den, num
        if num == 0: continue
        phi = (e * den - 1) // num if (e * den - 1) % num == 0 else None
        if phi is None: continue
        s = n - phi + 1
        disc = s * s - 4 * n
        if disc < 0: continue
        t = math.isqrt(disc)
        if t * t == disc and (s + t) % 2 == 0:
            p, q = (s + t) // 2, (s - t) // 2
            if p * q == n:
                return den  # d
    return None

def fermat(n, steps=1 << 20):
    a = math.isqrt(n)
    if a * a < n: a += 1
    for _ in range(steps):
        b2 = a * a - n
        b = math.isqrt(b2)
        if b * b == b2:
            return a - b, a + b
        a += 1
    return None

def small_e_roots(c, e, n):
    """Hastad: c = m^e mod n with tiny m and small e -> integer e-th root."""
    m, i = 0, 0
    # integer e-th root via binary search
    lo, hi = 0, 1 << ((c.bit_length() // e) + 2)
    while lo < hi:
        mid = (lo + hi) // 2
        if mid ** e < c: lo = mid + 1
        else: hi = mid
    if lo ** e == c:
        return lo
    return None

def decrypt(c, d, n):
    m = pow(c, d, n)
    b = i2b(m)
    return b

def try_print(b):
    try:
        s = b.decode("utf-8")
        if all(32 <= ord(ch) < 127 or ch in "\r\n\t" for ch in s):
            return s
    except Exception:
        pass
    return b.hex()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n"); ap.add_argument("--e", type=to_int)
    ap.add_argument("--c"); ap.add_argument("--ct-is-hex", action="store_true")
    ap.add_argument("--pub"); ap.add_argument("--p", type=to_int)
    ap.add_argument("--online-factordb", action="store_true",
                    help="query factordb (ONLY if competition rules allow)")
    a = ap.parse_args()

    if a.pub:
        n, e = read_pubkey(a.pub)
        print(f"[*] pubkey: n({n.bit_length()}b) e={e}")
    else:
        n = to_int(a.n, a.ct_is_hex and False or False)
        # allow hex n too: try hex if it starts with 0x or fails decimal
        try: n = to_int(a.n)
        except ValueError: n = int(a.n, 16)
        e = a.e
    c = to_int(a.c, a.ct_is_hex)

    p = a.p
    if p is None:
        if a.online_factordb:
            fs = factordb(n)
            if fs:
                p = fs[0]; print(f"[+] factordb: {len(fs)} factors")
        if p is None:
            print("[*] trying Fermat (close primes)...")
            fr = fermat(n)
            if fr: p, q = fr; print(f"[+] Fermat factors")
        if p is None:
            print("[*] trying Wiener (small d)...")
            d = wiener(n, e)
            if d:
                print(f"[+] d = {d}")
                print("[+] plaintext:", try_print(decrypt(c, d, n)))
                return
        if p is None and e <= 8:
            print("[*] trying small-e integer root (Hastad)...")
            m = small_e_roots(c, e, n)
            if m:
                print("[+] plaintext:", try_print(i2b(m)))
                return
    if p:
        q = n // p
        assert p * q == n, "bad factor"
        d = pow(e, -1, (p - 1) * (q - 1))
        print(f"[+] p = {p}\n[+] q = {q}\n[+] d = {d}")
        if c is not None:
            print("[+] plaintext:", try_print(decrypt(c, d, n)))
    else:
        print("[-] local attacks failed — try RsaCtfTool --attack all, or factordb if rules allow")

if __name__ == "__main__":
    main()
