#!/usr/bin/env python3
"""Carve full UTF-16LE / ASCII flag strings around 'created at 2025-09-10'."""
import re, mmap, sys

PATH = "/home/z/my-project/challenges/memdump.mem"
NEEDLE_UTF16 = "created at 2025-09-10".encode("utf-16-le")
NEEDLE_ASCII = b"created at 2025-09-10"
BRACE = "}".encode("utf-16-le")

f = open(PATH, "rb")
mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

print("== UTF-16LE matches ==")
seen = set()
pos = 0
count = 0
while count < 40:
    idx = mm.find(NEEDLE_UTF16, pos)
    if idx < 0:
        break
    pos = idx + 1
    count += 1
    # walk back to find '{' of CSG_FLAG
    start = mm.rfind("CSG_FLAG".encode("utf-16-le"), max(0, idx - 200), idx)
    if start < 0:
        continue
    # walk forward to closing brace
    end = mm.find(BRACE, idx)
    if end < 0 or end - start > 800:
        end = idx + 300
    raw = mm[start:end + 2]
    s = raw.decode("utf-16-le", errors="replace")
    s = s.split("}")[0] + "}" if "}" in s else s
    if s not in seen:
        seen.add(s)
        print(f"@0x{start:x}: {s!r}")

print("== ASCII matches ==")
seen = set()
pos = 0
count = 0
while count < 40:
    idx = mm.find(NEEDLE_ASCII, pos)
    if idx < 0:
        break
    pos = idx + 1
    count += 1
    start = mm.rfind(b"CSG_FLAG{", max(0, idx - 200), idx)
    if start < 0:
        continue
    end = mm.find(b"}", idx)
    if end < 0 or end - start > 800:
        end = idx + 300
    raw = mm[start:end + 1]
    s = raw.decode("latin-1", errors="replace")
    if s not in seen:
        seen.add(s)
        print(f"@0x{start:x}: {s!r}")
print(f"scanned, utf16 groups={len(seen)}")
