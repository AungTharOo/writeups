#!/usr/bin/env bash
# =============================================================================
# fat_recover.sh — Corrupted FAT12/16/32 image: check -> repair -> undelete -> extract
# =============================================================================
# WHY THIS EXISTS (tool-hint intelligence):
#   fsck.fat (dosfstools) sits on the approved list categorized "Reversing" —
#   a FILESYSTEM tool under REVERSING is a loud hint: expect a deliberately
#   corrupted FAT disk image (boot sector wiped, FAT chain broken, deleted file)
#   where you must repair before TSK/Autopsy can even open it. Pair with xz
#   (also approved, category Forensic) — the image may ship .xz-compressed.
#
# USAGE:  ./fat_recover.sh disk.img[.xz] [outdir]
# =============================================================================
IMG="${1:?usage: ./fat_recover.sh disk.img [outdir]}"
OUT="${2:-fat_out}"
mkdir -p "$OUT" || exit 1

echo "===== 0. DECOMPRESS + IDENTIFY ====="
case "$IMG" in
  *.xz)  xz -dk "$IMG" && IMG="${IMG%.xz}" ;;
  *.gz)  gunzip -k "$IMG" && IMG="${IMG%.gz}" ;;
esac
file "$IMG"                                   # "DOS/MBR boot sector" / FAT12/16/32
ls -la "$IMG"
echo "[*] partitioned image? check offsets:"; mmls "$IMG" 2>/dev/null || echo "(no partition table — whole-disk FAT, no -o offset needed)"

echo; echo "===== 1. READ-ONLY CHECK (never repair before you look) ====="
fsck.fat -v -n "$IMG" 2>&1 | tee "$OUT/fsck_check.txt"
grep -aiE "csg_flag|flag\{" "$OUT/fsck_check.txt" || true

echo; echo "===== 2. FLAG GREP ON RAW IMAGE (10 seconds, still free) ====="
strings -a "$IMG" | grep -aiE "csg_flag|flag\{|csg\{" | head
strings -el "$IMG" | grep -aiE "csg_flag|flag\{" | head

echo; echo "===== 3. REPAIR (auto-yes; interactive -r if you want control) ====="
cp "$IMG" "$OUT/backup.img"                   # ALWAYS keep the original
fsck.fat -v -y "$IMG" 2>&1 | tee "$OUT/fsck_repair.txt"
echo "[*] repaired copy made; re-run:  fls -r -p $IMG"

echo; echo "===== 4. UNDELETE (fsck.fat 4.1+ — deleted files stay in the root/FAT dir) ====="
cat <<'EOF'
fls -r -p -l disk.img | grep -i "\*"    # TSK marks deleted entries with *
# then undelete by PATH (writes recovered copy to CWD):
fsck.fat -u /FLAG.TXT disk.img          # repeat per file
# fsck.fat -u PATH prompts and writes fsck*.rec in the current directory
EOF

echo; echo "===== 5. TSK EXTRACTION (after repair) ====="
fls -r -p "$IMG" > "$OUT/listing.txt" 2>/dev/null && head -40 "$OUT/listing.txt"
echo "[*] pull a file by inode:  icat $IMG INODE > recovered.bin"
echo "[*] deleted-only view:     fls -r -p -d $IMG"
echo "[*] mount check (root in WSL/Kali):  sudo mount -o loop,ro $IMG /mnt/fat"

echo; echo "===== 6. IF STILL BROKEN — manual surgery (HxD / xxd) ====="
cat <<'EOF'
- Backup boot sector: FAT32 keeps a COPY at sector 6 (offset 0x1200 for 512B sectors)
    dd if=disk.img of=bs6.bin bs=512 skip=6 count=1
    dd if=bs6.bin of=disk.img bs=512 seek=0 count=1 conv=notrunc   # restore
- Two FATs: FAT#2 at reserved_sectors + fat_size — copy FAT#2 over FAT#1
    xxd -s 0 -l 64 disk.img     # read BPB: bytes/sec=11, resv=14-15, fats=16, fat_size=22-25
- Ongoing weirdness -> PyTSK/TSK still reads broken FATs that fsck refuses to touch:
    fls -r -p -f fat32 disk.img
- GUI double-check: Autopsy (Windows) — open image, run ingest, keyword CSG_FLAG
EOF
