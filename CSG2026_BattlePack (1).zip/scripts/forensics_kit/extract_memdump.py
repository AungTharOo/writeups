#!/usr/bin/env python3
"""Extract memdump.mem from deflate64 zip (stdlib zipfile + zipfile_deflate64 shim)."""
import zipfile, sys, time, os
import zipfile_deflate64  # noqa: F401  (patches zipfile with deflate64 support)

ZIP = "/home/z/my-project/challenges/memdump.zip"
OUT = "/home/z/my-project/challenges"

with zipfile.ZipFile(ZIP) as z:
    for info in z.infolist():
        print(f"{info.filename}  {info.file_size:,} bytes  method={info.compress_type}")
    names = z.namelist()
    for name in names:
        dest = os.path.join(OUT, os.path.basename(name))
        t0 = time.time()
        with z.open(name) as src, open(dest, "wb") as dst:
            total = 0
            while True:
                chunk = src.read(1 << 20)
                if not chunk:
                    break
                dst.write(chunk)
                total += len(chunk)
                if total % (256 << 20) < (1 << 20):
                    print(f"  ... {total:,} bytes ({time.time()-t0:.0f}s)", flush=True)
        print(f"extracted -> {dest} ({total:,} bytes in {time.time()-t0:.0f}s)", flush=True)
print("DONE")
