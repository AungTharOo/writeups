#!/usr/bin/env python3
"""
vigenere_solver.py — Vigenere solver: chi-squared key-length detection +
frequency-analysis key recovery. Works on A-Z text (spaces stripped for analysis).

Usage:
  python3 vigenere_solver.py ciphertext.txt            # auto-solve (key len 1..24)
  python3 vigenere_solver.py ct.txt -k SECRET          # decrypt with known key
  python3 vigenere_solver.py ct.txt -L 5               # force key length
"""
import argparse, sys

ENG = [0.08167,0.01492,0.02782,0.04253,0.12702,0.02228,0.02015,0.06094,0.06966,
0.00153,0.00772,0.04025,0.02406,0.06749,0.07507,0.01929,0.00095,0.05987,0.06327,
0.09056,0.02758,0.00978,0.02360,0.00150,0.01974,0.00074]

def clean(t): return "".join(c for c in t.upper() if "A" <= c <= "Z")

def ic(s):
    n = len(s)
    if n < 2: return 0
    from collections import Counter
    c = Counter(s)
    return sum(v * (v - 1) for v in c.values()) / (n * (n - 1))

def key_len(text, maxlen=24):
    best = []
    for L in range(1, maxlen + 1):
        cols = [text[i::L] for i in range(L)]
        avg = sum(ic(c) for c in cols) / L
        best.append((avg, L))
    best.sort(reverse=True)
    return best[:6]

def chi_shift(col):
    from collections import Counter
    n = len(col); c = Counter(col); best = (1e9, 0)
    for s in range(26):
        chi = 0
        for i in range(26):
            exp = ENG[i] * n
            obs = c.get(chr((i + s) % 26 + 65), 0)
            chi += (obs - exp) ** 2 / exp
        if chi < best[0]: best = (chi, s)
    return best[1]

def solve(text, L):
    key = "".join(chr(chi_shift(text[i::L]) + 65) for i in range(L))
    return key

def decrypt(text, key):
    out, k = [], clean(key)
    j = 0
    for ch in text:
        if "A" <= ch <= "Z":
            out.append(chr((ord(ch) - 65 - (ord(k[j % len(k)]) - 65)) % 26 + 65))
            j += 1
        else:
            out.append(ch)
    return "".join(out)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("-k", "--key"); ap.add_argument("-L", "--len", type=int)
    a = ap.parse_args()
    t = clean(open(a.file, encoding="utf-8", errors="replace").read())
    if a.key:
        print(decrypt(t, a.key)); sys.exit(0)
    if a.len:
        k = solve(t, a.len)
        print(f"[*] key(L={a.len}) = {k}\n")
        print(decrypt(t, k)); sys.exit(0)
    print("[*] candidate key lengths (IC):")
    for avg, L in key_len(t):
        k = solve(t, L)
        print(f"  L={L:2d} IC={avg:.4f} key={k:24s} preview={decrypt(t[:60], k)!r}")
