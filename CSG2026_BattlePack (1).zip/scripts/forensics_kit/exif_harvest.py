#!/usr/bin/env python3
"""
exif_harvest.py — Recursive metadata harvester (wraps exiftool, falls back to
pure-python EXIF for JPG). Outputs CSV of interesting fields + flags grep.

Usage:
  python3 exif_harvest.py <dir-or-file>          # harvest everything
  python3 exif_harvest.py photos/ -o meta.csv
"""
import csv, os, subprocess, sys

FIELDS = ["FileName", "FileSize", "DateTimeOriginal", "CreateDate", "ModifyDate",
          "Artist", "Author", "Copyright", "Comment", "Description", "ImageDescription",
          "GPSPosition", "GPSLatitude", "GPSLongitude", "Software", "Model", "Make",
          "CameraModel", "DocumentID", "URL", "Title", "Subject", "Producer", "Creator"]

def harvest(path, rows):
    if os.path.isdir(path):
        for root, _, files in os.walk(path):
            for f in files:
                harvest(os.path.join(root, f), rows)
        return
    try:
        p = subprocess.run(["exiftool", "-j", "-a", "-u", "-G1", path],
                           capture_output=True, timeout=30)
        if p.returncode != 0:
            return
        import json
        data = json.loads(p.stdout.decode(errors="replace"))[0]
    except Exception:
        return
    row = {"path": path}
    blob = []
    for k, v in data.items():
        short = k.split(":", 1)[-1]
        blob.append(f"{short}={v}")
        if short in FIELDS:
            row[short] = str(v)
    row["all"] = " | ".join(blob)
    rows.append(row)
    # flag grep
    import re
    m = re.search(r"CSG_FLAG\{[^}]*\}|flag\{[^}]*\}", row["all"], re.I)
    if m:
        print(f"[!!!] FLAG in metadata of {path}: {m.group(0)}")

if __name__ == "__main__":
    target = sys.argv[1]
    out = "meta.csv"
    if "-o" in sys.argv:
        out = sys.argv[sys.argv.index("-o") + 1]
    rows = []
    harvest(target, rows)
    keys = ["path"] + FIELDS + ["all"]
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    print(f"[+] {len(rows)} files harvested -> {out}")
