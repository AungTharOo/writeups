# CSG 2026 BATTLE PACK — Full Cheatsheet Edition (v5)

Everything allowed by the Cyber SEA Game rules ("personal notes, printed references,
cheat sheets, scripts created before the competition") in one offline bundle.

## What's inside

| File | What it is |
|---|---|
| **`blueprint/index.html`** | **NEW v5 — THE 2026 BLUEPRINT SITE (open this first!)** An offline docs site (works 100% from `file://`, no internet): Home = tool-hints → predicted-challenges matrix with live links; **10 step-by-step Playbooks** for every predicted challenge (memory→SSH keys, disk, PDF stego, CAN bus, QR, crypto/RSA, stego, PCAP, reversing, web); **one page per approved tool (1–39)** in official-list order (purpose → commands → CTF walkthrough → gotchas); 21 extra command sheets; script-failure fallbacks; A–Z of all 191 tools; **offline search**. Print any page with Ctrl+P (print CSS included) |
|---|---|
| `CSG2026_Handbook.pdf` | **Vol 1 — Battle Handbook** (34 pages, ~11.3k words): 2026 prediction matrix, master triage, **13 walkthrough chains**, **3 solved CSG2025 battle logs**, category deep-dives, CyberChef recipes, TLDR tables, strategy, A–Z appendix of all 191 approved tools, banned-tools list, script reference |
| `CSG2026_Tool_Sheets.pdf` | **Vol 2 — Tool Usage Sheets** (49 pages, ~16k words): *The 2026 Blueprint — Tool Hints → Predicted Challenges* as detailed per-tool command manuals. 8 battle zones × ~55 tool sheets: full syntax, key-flag tables, worked examples, expected output, **"if it fails" recovery** — plus Section 09: manual fallbacks for every kit script, and the A–Z appendix of all 191 tools with usage lines |
| `CSG2026_Handbook.html` / `CSG2026_Tool_Sheets.html` | Editable sources — open in any browser, print more copies |
| `SOLVE_LOG_CSG2025_Combined_Challenge.md` | Reversing+Network+Forensic pack: solved end-to-end (flag: `R3v3rsing_@nd_N3tw0rk_F0r3nsic_Ch@ll3ng3_S0lv3d!!`) |
| `SOLVE_LOG_CSG2025_Forensics_Pair.md` | memdump.zip (5 GB RAM dump) + evidence.zip ($MFT/$J/prefetch): both solved, commands validated live |
| `scripts/` | 4 pre-made kits (crypto / stego / network / forensics), stdlib + pycryptodome only |

## Why three formats

- **Blueprint site (v5)** = the day-of cockpit: sidebar navigation, offline search, numbered
  playbook steps with "if it fails" branches at every step. Nothing depends on a script running.
- **Vol 1 (Handbook)** = the *chains*: what order to run things, how the CSG2025 packs
  were actually solved, competition strategy.
- **Vol 2 (Tool Sheets)** = the same tool manuals as print-ready PDF: if a pre-made script dies
  mid-competition, open the matching sheet and **type the manual commands** — every flag,
  example, expected output, and recovery move is written out. Section 09 maps every kit script
  to its manual equivalent ("scripts might not work → you can always type it").

**Using the site:** unzip the pack anywhere (even USB) → open `blueprint/index.html` in any
browser → sidebar = all 75 pages → top-right Search works offline. On the competition machine,
copy the `blueprint/` folder + `scripts/` folder to the Desktop — both are permitted personal
notes/references under the rules.

## The one-minute version

1. Flag format is `CSG_FLAG{...}` — grep for it first, in ASCII **and** UTF-16LE.
2. The approved-tools list telegraphs the challenge mix → Section 01 matrix of Vol 2 /
   Section 02 of Vol 1 (qpdf→PDF stego, vol3+OpenSSH-key-recovery→memory/SSH decrypt,
   can-utils→CAN bus, ZBar→QR, TSK+fsck.fat→disk/FAT).
3. File in hand → matching zone in Vol 2 → run the sheet's first commands → if stuck,
   the Vol 1 chain gives the full narrative.
4. Script traceback? Vol 2 Section 09 = manual fallback for every script.
5. 5 GB dump on a small laptop? Zone 1 sheet 1.4: grep first, vol3 later.

## Quick script index (forensics_kit highlights, all battle-tested)

```bash
python3 scripts/forensics_kit/mft_triage.py '$MFT' --find-created "2025-09-10 08:18:20" --tz-hours 8
python3 scripts/forensics_kit/mft_triage.py '$MFT' --grep-data "CSG_FLAG|flag\{"
python3 scripts/forensics_kit/usnjrnl_triage.py '$J' --name flag
python3 scripts/forensics_kit/extract_memdump.py          # deflate64 zip gotcha handled
python3 scripts/forensics_kit/carve_hint_flag.py          # UTF-16LE flag carving from raw dumps
python3 scripts/forensics_kit/il_extract.py               # .NET IL from raw dump (base brute-force)
./scripts/forensics_kit/ssh_key_recovery.sh dump.mem cap.pcap
```

Full reference: Appendix C of Vol 1. Every script has `--help`. Manual equivalents for
every script: Section 09 of Vol 2.

## Setup (once, on your own machine — legal, it's your prep)

```bash
pip install pycryptodome dnfile dncil        # the only non-stdlib deps
python3.13 -m pip install zipfile-deflate64 inflate64   # deflate64 archives
```

Practice: Oct 19–23. Competition: Oct 26–27. No AI/ML tools at the desk — this pack is
the AI-free brain.
