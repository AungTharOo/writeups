#!/usr/bin/env python3
"""il_dump.py — Dump IL of all methods in a .NET assembly (dnfile+dncil)."""
import sys, dnfile
import dncil  # noqa
from dncil.cil.body import CilMethodBody
from dncil.cil.error import MethodBodyFormatError
from dncil.clr.token import Token, StringToken, InvalidToken
from dncil.cil.opcode import OpCodes

path = sys.argv[1]
pe = dnfile.dnPE(path)

TABLES = {0x01:"TypeRef",0x02:"TypeDef",0x04:"Field",0x06:"MethodDef",0x0A:"MemberRef",
          0x1B:"MethodSpec",0x2B:"MethodSemantics",0x11:"StandAloneSig",0x23:"AssemblyRef"}

def resolve(token):
    if isinstance(token, StringToken):
        try:
            return '"' + pe.net.user_strings.get(token.rid).value + '"'
        except Exception:
            return "<str?>"
    tname = TABLES.get(token.table, f"tbl{token.table:#x}")
    try:
        table = getattr(pe.net.mdtables, tname, None)
        if table is None: return f"{tname}:{token.rid}"
        row = table.rows[token.rid - 1]
        nm = getattr(row, "Name", None)
        if nm is None:
            return f"{tname}:{token.rid}"
        name = str(nm)
        # try to qualify MemberRef with class name
        if tname == "MemberRef":
            try:
                cls = row.Class.row
                cn = getattr(cls, "TypeName", None) or getattr(cls, "Name", "")
                ns = getattr(cls, "TypeNamespace", "")
                name = f"{ns}.{cn}::{name}" if ns else f"{cn}::{name}"
            except Exception: pass
        elif tname in ("TypeDef", "TypeRef"):
            ns = getattr(row, "TypeNamespace", "")
            tn = getattr(row, "TypeName", "")
            name = f"{ns}.{tn}" if ns else tn
        return name
    except Exception:
        return f"{tname}:{token.rid}"

for row in pe.net.mdtables.MethodDef:
    if not row.ImplFlags.miIL or row.Flags.mdAbstract or row.Flags.mdPinvokeImpl:
        continue
    try:
        rva = row.Rva
        if rva == 0: continue
        body = CilMethodBody(dncil_reader(pe, rva)) if False else None
    except Exception:
        continue

# simpler: iterate methods via dncil helper
from dncil.cil.body.reader import CilMethodBodyReaderBase

class DnfileMethodBodyReader(CilMethodBodyReaderBase):
    def __init__(self, pe, row):
        self.pe = pe
        self.offset = self.pe.get_offset_from_rva(row.Rva)
    def read(self, n):
        data = self.pe.get_data(self.pe.get_rva_from_offset(self.offset), n)
        self.offset += n
        return data
    def tell(self): return self.offset
    def seek(self, o): self.offset = o; return self.offset

print("=" * 78)
for row in pe.net.mdtables.MethodDef:
    if row.Rva == 0: continue
    print(f"\n### METHOD: {row.Name}  (rva={row.Rva:#x})")
    try:
        body = CilMethodBody(DnfileMethodBodyReader(pe, row))
    except MethodBodyFormatError as e:
        print("  <format error>", e); continue
    for insn in body.instructions:
        op = str(insn.opcode)
        operand = ""
        if insn.operand is not None:
            if isinstance(insn.operand, Token):
                operand = resolve(insn.operand)
            else:
                operand = str(insn.operand)
        print(f"  IL_{insn.offset - body.offset:04X}: {op:12s} {operand}")
