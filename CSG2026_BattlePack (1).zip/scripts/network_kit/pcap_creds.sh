#!/usr/bin/env bash
# pcap_creds.sh — One-shot credential & artifact harvest from a pcap/pcapng.
# Usage: bash pcap_creds.sh capture.pcapng [outdir]
set -uo pipefail
PCAP="${1:?usage: pcap_creds.sh capture.pcap [outdir]}"
OUT="${2:-creds_out}"
mkdir -p "$OUT"
T=tshark

echo "== protocol hierarchy =="
$T -r "$PCAP" -q -z io,phs | tee "$OUT/protocols.txt"

echo "== HTTP basic auth / posts =="
$T -r "$PCAP" -Y "http.authbasic" -T fields -e ip.src -e http.authbasic | tee "$OUT/http_basic.txt"
$T -r "$PCAP" -Y "http.request.method==POST" -T fields -e ip.src -e http.request.uri -e urlencoded-form.key -e urlencoded-form.value | tee "$OUT/http_posts.txt"

echo "== FTP =="
$T -r "$PCAP" -Y "ftp.request.command in {\"USER\" \"PASS\"}" -T fields -e ftp.request.command -e ftp.request.arg | tee "$OUT/ftp.txt"

echo "== SMTP/POP/IMAP =="
$T -r "$PCAP" -Y "smtp.req.command==AUTH || pop.request.command==\"USER\" || pop.request.command==\"PASS\" || imap.request" -T fields -e ip.src -e imap.request -e pop.request.command -e smtp.req.command | tee "$OUT/mail.txt"

echo "== telnet stream (follow all tcp, grep) =="
n=$($T -r "$PCAP" -T fields -e tcp.stream 2>/dev/null | sort -un | tail -1)
for i in $(seq 0 "${n:-0}"); do
  $T -r "$PCAP" -q -z follow,tcp,ascii,"$i" 2>/dev/null | grep -aiE "login|password|user|pass|flag\{|csg" \
    | sed "s/^/[stream $i] /" >> "$OUT/streams_hits.txt"
done
grep -a "csg_flag\|flag{" "$OUT/streams_hits.txt" 2>/dev/null

echo "== DNS queries (exfil check: long subdomains) =="
$T -r "$PCAP" -T fields -e dns.qry.name | awk 'length($0)>40' | sort -u | tee "$OUT/dns_long.txt"

echo "== export objects =="
$T -r "$PCAP" --export-objects "http,$OUT/http_obj" 2>/dev/null
$T -r "$PCAP" --export-objects "smb,$OUT/smb_obj" 2>/dev/null
ls -la "$OUT/http_obj" "$OUT/smb_obj" 2>/dev/null | head -30

echo "== flag grep across all extracted =="
grep -raiE "csg_flag\{[^}]*\}|flag\{[^}]*\}" "$OUT" 2>/dev/null | head
echo "[+] done -> $OUT/"
