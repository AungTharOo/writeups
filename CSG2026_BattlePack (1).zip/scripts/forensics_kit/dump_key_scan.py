#!/usr/bin/env python3
"""
dump_key_scan.py — Scan a memory dump for the AES key that decrypts the CSG blob.
Screen: p2 = D(C2) ^ C1 printable (IV-independent CBC property). Verify on all blocks.
"""
import base64, time, sys
from Crypto.Cipher import AES

CT = base64.b64decode("1KeGOcMvvKpPbxrNRdyqJmSGh3j+ZCvIT5RKk6lTBkSGBYSYrX7dy3Q/E8wVuQAXNFMs978T1A4qyx7EeX9fvg==")
BLOCKS = [CT[i:i+16] for i in range(0, len(CT), 16)]

DUMP = "/home/z/my-project/challenges/csg2025/csg_reversing_network_forensic_challenge/csg_reversing_network_forensic_challenge.DMP"

def pr(b):
    return sum(1 for x in b if 32 <= x < 127 or x in (9, 10, 13)) / len(b)

def verify(k):
    ecb = AES.new(k, AES.MODE_ECB)
    plains = []
    for i in range(1, len(BLOCKS)):
        d = ecb.decrypt(BLOCKS[i])
        plains.append(bytes(a ^ b for a, b in zip(d, BLOCKS[i-1])))
    score = sum(pr(p) for p in plains) / len(plains)
    return score, plains

def main():
    data = open(DUMP, "rb").read()
    n = len(data)
    print(f"[*] dump {n:,}B")
    C2 = BLOCKS[1]
    t0 = time.time()
    hits = []
    for klen in (32, 16):
        step = 8
        cnt = 0
        for i in range(0, n - klen, step):
            cand = data[i:i+klen]
            cnt += 1
            if cnt % 2_000_000 == 0:
                el = time.time()-t0
                print(f"  ... {cnt:,} tried, {i/n*100:.0f}%, {el:.0f}s", flush=True)
            # screen with 1 block
            try:
                d2 = AES.new(cand, AES.MODE_ECB).decrypt(C2)
            except Exception:
                continue
            p2 = bytes(a ^ b for a, b in zip(d2, BLOCKS[0]))
            if pr(p2) >= 0.85:
                score, plains = verify(cand)
                print(f"[HIT?] off={i:#x} klen={klen} score={score:.2f} p2={p2!r}", flush=True)
                if score >= 0.9:
                    hits.append((i, klen, cand, score, plains))
        print(f"[*] klen={klen} scan done in {time.time()-t0:.0f}s, hits={len(hits)}")
        if hits:
            break
    for i, klen, k, s, plains in hits[:5]:
        print("="*60)
        print(f"KEY at dump offset {i:#x} ({klen}B): {k.hex()}")
        for p in plains:
            print("   P:", p)
        # derive IV: IV = D(C1) ^ P1  (P1 = assumed '2025-09-07 ...' start)
        ecb = AES.new(k, AES.MODE_ECB)
        iv = bytes(a ^ b for a, b in zip(ecb.decrypt(BLOCKS[0]), b"2025-09-07 06:03:0"))
        print("IV (if P1='2025-09-07 06:03:0'):", iv.hex())
    if not hits:
        print("[-] no key found at step=8 — try step=4 or step=1")

if __name__ == "__main__":
    main()
