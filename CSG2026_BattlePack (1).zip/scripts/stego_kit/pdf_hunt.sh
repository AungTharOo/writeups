#!/usr/bin/env bash
# =============================================================================
# pdf_hunt.sh — PDF stego & forensics triage
# =============================================================================
# WHY THIS EXISTS (tool-hint intelligence):
#   The approved list puts TWO PDF tools under category "Stegano":
#     qpdf  -> Category: Stegano      PDF Viewer -> Category: Stegano
#   plus pdftotext under OSINT. That is a leaked hint: a PDF challenge is coming
#   and the flag hides INSIDE the PDF structure (objects/streams/metadata/
#   attachments/JS/white-on-white text), not in the visible page.
#
# USAGE:  ./pdf_hunt.sh suspicious.pdf [outdir]     (default outdir: pdf_hunt_out)
# ORDER MATTERS: cheap greps first, structural dump second, render last.
# =============================================================================
PDF="${1:?usage: ./pdf_hunt.sh file.pdf [outdir]}"
OUT="${2:-pdf_hunt_out}"
mkdir -p "$OUT" || exit 1
echo "[*] output dir: $OUT"

echo; echo "===== 0. RAW GREP (10 seconds — always first) ====="
strings -a "$PDF" | grep -aiE "csg_flag|flag\{|csg\{|pass|secret|key" | head -20
strings -el "$PDF" | grep -aiE "csg_flag|flag\{" | head -10
rg -a --no-heading -i "csg_flag|flag\{" "$PDF" 2>/dev/null | head -5

echo; echo "===== 1. STRUCTURE RECON ====="
pdfinfo "$PDF" 2>/dev/null || python3 - "$PDF" <<'EOF'
import sys; p=sys.argv[1]
d=open(p,'rb').read(); print("size:",len(d),"| %%EOF count:",d.count(b'%%EOF'),
      "| obj count:",d.count(b' obj'),"| streams:",d.count(b'stream'))
EOF
echo -n "EOF markers (multiple = incremental updates = hidden layers!): "
grep -ac "%%EOF" "$PDF" 2>/dev/null || true

echo; echo "===== 2. DANGEROUS-OBJECT SCAN (pdfid) ====="
pdfid.py "$PDF" 2>/dev/null || echo "(pdfid missing — grep manually: obj /JS /OpenAction /AA /EmbeddedFile /Launch)"
grep -aoE "/JavaScript|/OpenAction|/AA|/EmbeddedFile|/Launch|/RichMedia|/FileAttachment" "$PDF" | sort | uniq -c

echo; echo "===== 3. QPDF — INFLATE EVERYTHING (the hint tool) ====="
qpdf --check "$PDF" 2>&1 | head -15
# --qdf + disable object streams = every stream inflated, readable in HxD/less
qpdf --qdf --object-streams=disable --decode-level=generalized "$PDF" "$OUT/flat.pdf" \
  && echo "[+] flat PDF written: $OUT/flat.pdf (open in HxD / less)"
# encrypted? decrypt + drop restrictions:
qpdf --decrypt --remove-restrictions "$PDF" "$OUT/dec.pdf" 2>/dev/null && echo "[+] decrypted copy: $OUT/dec.pdf"
qpdf --show-object=trailer "$PDF" 2>/dev/null | head -20

echo; echo "===== 4. TEXT EXTRACTION (visible AND invisible) ====="
pdftotext -layout "$PDF" "$OUT/text.txt" 2>/dev/null && cat "$OUT/text.txt" | head -60
echo "--- raw text layer (incl. off-page / white text positions) ---"
pdftotext -raw "$PDF" - 2>/dev/null | grep -aiE "csg|flag|key|pass" | head

echo; echo "===== 5. EMBEDDED FILES + IMAGES ====="
pdfimages -all "$PDF" "$OUT/img" 2>/dev/null && ls -la "$OUT"/img* 2>/dev/null
pdfdetach -list "$PDF" 2>/dev/null
for n in $(seq 1 20); do pdfdetach -save $n -o "$OUT/attach_$n" "$PDF" 2>/dev/null; done
# every extracted image -> run the image stego ladder next (zsteg/stegseek):
#   zsteg -a "$OUT"/img-000.png ; stegseek "$OUT"/img-001.jpg --crack

echo; echo "===== 6. TRAILING DATA + RENDER-COMPARE ====="
python3 "$(dirname "$0")/trailing_data.py" "$PDF" 2>/dev/null || xxd "$PDF" | tail -15
mutool draw -o "$OUT/page%d.png" -r 100 "$PDF" 1-30 2>/dev/null || \
  pdftoppm -png -r 100 "$PDF" "$OUT/page" 2>/dev/null
echo "[*] rendered pages -> compare with text.txt: text invisible on render = hidden layer"
echo "    or flag only visible in render (vector shapes) = inspect page PNGs, run OCR-free zbarimg"

echo; echo "===== 7. SECOND-OPINION TOOLS ====="
echo "  peepdf-3 '$PDF'        # interactive: object tree, JS deobfuscation"
echo "  pdf-parser.py --object N '$PDF'   # dump one object raw"
echo "  exiftool -a -u -g1 '$PDF'         # Producer/Author/History metadata dorks"
