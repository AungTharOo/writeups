#!/usr/bin/env python3
"""
trailing_data.py — Detect & extract trailing data after image EOF markers
(PNG IEND, JPEG EOI, GIF trailer) + report anomalies (extra chunks, bad CRCs).

Usage: python3 trailing_data.py image.png [more images...]
"""
import sys, struct, zlib

MARKERS = {b"\x89PNG\r\n\x1a\n": "PNG", b"\xff\xd8\xff": "JPEG", b"GIF8": "GIF"}

def png_chunks(data):
    off, chunks = 8, []
    while off + 8 <= len(data):
        ln = int.from_bytes(data[off:off+4], "big")
        typ = data[off+4:off+8]
        body = data[off+8:off+8+ln]
        crc_stored = data[off+8+ln:off+12+ln]
        crc_ok = zlib.crc32(typ + body) == int.from_bytes(crc_stored, "big") if len(crc_stored) == 4 else False
        chunks.append((typ, ln, crc_ok))
        off += 12 + ln
        if typ == b"IEND":
            break
    return chunks, off

def analyze(path):
    data = open(path, "rb").read()
    kind = next((v for k, v in MARKERS.items() if data.startswith(k)), None)
    if kind is None:
        print(f"{path}: unknown format {data[:8]!r}"); return
    print(f"\n=== {path} [{kind}, {len(data):,}B] ===")
    if kind == "PNG":
        chunks, end = png_chunks(data)
        for typ, ln, ok in chunks:
            mark = "" if ok else "  [!] BAD CRC"
            extra = "  [!] UNUSUAL" if typ not in (b"IHDR",b"IDAT",b"IEND",b"PLTE",b"tRNS",b"pHYs",b"tEXt",b"zTXt",b"iTXt",b"sRGB",b"gAMA",b"cHRM",b"bKGD",b"sBIT",b"tIME") else ""
            print(f"  {typ.decode(errors='replace'):5s} {ln:>10,}B crc_ok={ok}{mark}{extra}")
        print(f"  chunks end at offset {end:,}; file size {len(data):,}")
        if end < len(data):
            tail = data[end:]
            print(f"  [!!!] TRAILING DATA {len(tail):,}B after IEND:")
            print(f"  head hex: {tail[:64].hex(' ')}")
            txt = "".join(chr(b) if 32 <= b < 127 else "." for b in tail[:200])
            print(f"  ascii   : {txt}")
            open(path + ".trailing.bin", "wb").write(tail)
            print(f"  [+] saved -> {path}.trailing.bin")
    elif kind == "JPEG":
        off = 2
        while off + 4 <= len(data):
            if data[off] != 0xFF: break
            m = data[off+1]
            if m == 0xD9:
                end = off + 2; break
            if 0xD0 <= m <= 0xD7 or m == 0x01:
                off += 2; continue
            ln = int.from_bytes(data[off+2:off+4], "big")
            off += 2 + ln
            if m == 0xDA:  # scan data: find next marker
                while off + 1 < len(data):
                    if data[off] == 0xFF and 0xD0 <= data[off+1] <= 0xD9:
                        break
                    off += 1
        else:
            end = len(data)
        print(f"  EOI at {end:,}; file size {len(data):,}")
        if end < len(data):
            tail = data[end:]
            print(f"  [!!!] TRAILING DATA {len(tail):,}B: {tail[:64].hex(' ')}")
            open(path + ".trailing.bin", "wb").write(tail)
            print(f"  [+] saved -> {path}.trailing.bin")

if __name__ == "__main__":
    for p in sys.argv[1:]:
        analyze(p)
