#!/usr/bin/env python3
"""
unmap_memory_pe.py - reconstruct a file-aligned PE from an in-memory (section-aligned) dump.
Usage: unmap_memory_pe.py <carved.bin> <out.bin>
"""
import struct, sys

src, dst = sys.argv[1], sys.argv[2]
data = open(src, "rb").read(64 << 20)

e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
assert data[e_lfanew:e_lfanew + 4] == b"PE\x00\x00", "bad PE"
coff = e_lfanew + 4
nsec, opt_size = struct.unpack_from("<HH", data, coff + 2)
opt = coff + 20
magic = struct.unpack_from("<H", data, opt)[0]
print(f"machine=0x{struct.unpack_from('<H', data, coff)[0]:x} nsec={nsec} optmagic=0x{magic:x} optsize={opt_size}")

sec_off = opt + opt_size
size_of_image = struct.unpack_from("<I", data, opt + 56)[0]
size_of_headers = struct.unpack_from("<I", data, opt + 60)[0]
print(f"SizeOfImage=0x{size_of_image:x} SizeOfHeaders=0x{size_of_headers:x}")

out = bytearray(max(size_of_headers, 0x400) + 0x100000)
# copy headers
out[:size_of_headers] = data[:size_of_headers]

total_end = size_of_headers
for i in range(nsec):
    s = sec_off + i * 40
    name = data[s:s + 8].rstrip(b"\x00").decode("latin-1", "replace")
    vsize, va, rawsize, rawptr = struct.unpack_from("<IIII", data, s + 8)
    print(f"  sec[{i}] {name:8} VA=0x{va:x} VS=0x{vsize:x} RawPtr=0x{rawptr:x} RawSize=0x{rawsize:x}")
    take = min(vsize or rawsize, len(data) - va)
    chunk = data[va:va + take]
    need = rawptr + max(rawsize, len(chunk))
    if need > len(out):
        out.extend(b"\x00" * (need - len(out)))
    out[rawptr:rawptr + len(chunk)] = chunk
    total_end = max(total_end, rawptr + max(rawsize, vsize))

with open(dst, "wb") as f:
    f.write(out[:total_end])
print(f"written {dst} ({total_end} bytes)")
