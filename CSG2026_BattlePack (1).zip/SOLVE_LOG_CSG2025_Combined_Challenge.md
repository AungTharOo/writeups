# SOLVE LOG — CSG 2025 "Reversing + Network + Forensic" Combined Challenge
*Solved end-to-end during preparation (Oct 19, 2026). Every step validated with the
exact scripts shipped in this pack.*

## Artifacts
- `csg_reversing_network_forensic_challenge.pcapng` (4.7 KB, dumpcap, Win10 21H2)
- `csg_reversing_network_forensic_challenge.DMP` (94 MB Windows **minidump** of a .NET process)

## Solve chain (7 steps)

### 1. Triage the capture
```bash
python3 pcap_reassemble.py csg...pcapng      # pure-python pcapng parser
# 47 packets, two flows:
#   SMB :445  → only keepalives (red herring)
#   TCP :8553 → custom protocol!
```
Key insight: the client streams the command **one UTF-16LE char per TCP segment**
(`74 00 00 00 00 00` = 't' ... `0d 0a` = CRLF) → command is `type c:\tmp\flag.txt`.
Server answers with ONE base64 line:
`1KeGOcMvvKpPbxrNRdyqJmSGh3j+ZCvIT5RKk6lTBkSGBYSYrX7dy3Q/E8wVuQAXNFMs978T1A4qyx7EeX9fvg==`
= **64 bytes = 4 AES blocks** (PKCS7).

### 2. Triage the minidump
```bash
python3 carve_module.py csg...DMP --list
# [SystemInfo] + 38 modules → it's a .NET app:
#   csg_reversing_network_forensic_challenge.exe  (host)
#   ajccbc_reversing_challenge.dll                (the logic!)
```

### 3. Carve the managed DLL out of the dump
```bash
python3 carve_module.py csg...DMP ajccbc_reversing_challenge.dll --unmap -o aj.dll
# PE32+ .NET assembly, 2 sections — the --unmap step converts the memory-mapped
# image back to a file-aligned PE so dnfile/ILSpy/dnSpyEx can parse it.
```

### 4. Read the IL (dnSpyEx on comp; dnfile+dncil here)
```bash
python3 il_dump.py aj.dll > il.txt
```
Recovered logic:
- ctor: `key = UTF8(AdvancedDecode(STR1))`, `iv = UTF8(AdvancedDecode(STR2))`
- `AdvancedDecode(s)` = **hex-decode → XOR with `simplekey`** (static field, cycling)
- `obfuscate(x)` = `Aes.Create()` + Key/IV + CBC default + PKCS7 + `ToBase64String`
- `RemoteShell` on :8553 runs `cmd.exe /c <cmd>`, replies `obfuscate(output)`
- Bonus: exfils results to a Blogger blog via deobfuscated OAuth creds (3-part b64)

### 5. Layer the key
```
STR1 = 2a5b05310e08081f2b3405031134372a073c1f1c371a2e1c09303b4308393219
XOR "simplekey" → "Y2hAbmczRGlnaXRAbEluZjBybUB0aTBu"   ← looks like base64!
base64-decode   → "ch@ng3Digit@lInf0rm@ti0n"            ← 24 bytes = AES-192!
STR2 = 252e0a0a3a1f291c1b343b39212b3c11013d312f08315158
XOR "simplekey" → "VGgzVzBybGRTQGYzdDBFeA==" → "Th3W0rld@f3t0Ex"  ← 16-byte IV
```

### 6. Decrypt
```python
AES.new(b"ch@ng3Digit@lInf0rm@ti0n", AES.MODE_CBC, b"Th3W0rld@f3t0Ex").decrypt(ct)
# → R3v3rsing_@nd_N3tw0rk_F0r3nsic_Ch@ll3ng3_S0lv3d!!
```

### 7. Flag
`CSG_FLAG{R3v3rsing_@nd_N3tw0rk_F0r3nsic_Ch@ll3ng3_S0lv3d!!}`

## Lessons burned into the playbook
1. **Key sizes: scan 16 AND 24 AND 32.** The first dump-scan pass tried only 16/32 and
   missed the AES-192 key completely. `aes_key_hunt.py` now scans all three.
2. **Multi-layer encoding is the norm:** hex → XOR(fixed string) → base64 → printable
   key. Decode until it hurts.
3. **CBC middle-block property validates a key withOUT knowing the IV**:
   `P2 = D(C2) ^ C1` is IV-independent. Use it to test candidate keys fast.
   (Score by "fraction of blocks ≥90% printable" — PKCS7 pad block is not printable.)
4. **Minidump ≠ full memory image**, but ModuleListStream + Memory64ListStream are
   enough to carve loaded managed DLLs → IL → logic.
5. **Custom protocols on high ports:** follow TCP stream in Wireshark (reassembly!),
   look at per-segment payload structure (here: 1 UTF-16 char/segment).
6. A 94 MB dump can be triaged in minutes if you go straight for modules + strings.
