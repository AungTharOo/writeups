#!/usr/bin/env python3
"""
il_extract.py - brute-force module base of a .NET assembly in a raw memory dump,
extract IL of each method, disassemble with dncil.
"""
import struct, sys

DUMP = "/home/z/my-project/challenges/memdump.mem"
ROOT = 0x15efa650

sys.path.insert(0, "/home/z/my-project/scripts")
import importlib.util
spec = importlib.util.spec_from_file_location("mm", "/home/z/my-project/scripts/mft_meta.py")
mm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mm)

CHUNK = 0x4000  # read 16KB window per probe

def read(f, off, n):
    f.seek(off)
    b = f.read(n)
    return b if len(b) == n else b + b"\x00" * (n - len(b))

def method_header(buf):
    """Return (header_size, code_size, header_bytes) or None."""
    b0 = buf[0]
    if (b0 & 3) == 2:  # tiny
        size = b0 >> 2
        if 1 <= size <= 0x800:
            return 1, size, 1
        return None
    if (b0 & 3) == 3:  # fat
        if len(buf) < 12:
            return None
        flags_size = struct.unpack_from("<H", buf, 0)[0]
        hsize = (flags_size >> 12) * 4
        if hsize != 12:
            return None
        csize = struct.unpack_from("<I", buf, 4)[0]
        if 1 <= csize <= 0x10000:
            return hsize, csize, hsize
        return None
    return None

def main():
    f = open(DUMP, "rb")
    ver, streams = mm.parse_meta(f, ROOT)
    tables = mm.parse_tables(f, *streams["#~"])
    methods, _ = mm.get_methoddefs(tables)
    print(f"{len(methods)} methods")

    root_low = ROOT & 0xFFF
    candidates = []
    for extra in range(0, 0x100, 0x10):  # meta rva low bits vary by file alignment
        for k in range(1, 16):
            meta_rva = (k << 12) | ((ROOT - (k << 12) - extra) & 0xFFF) if False else (k << 12) + root_low - extra
            if meta_rva <= 0x1000:
                continue
            base = ROOT - meta_rva
            if base <= 0:
                continue
            candidates.append((base, meta_rva))
    # dedupe
    candidates = sorted(set(candidates))

    best = None
    for base, meta_rva in candidates:
        ok = 0
        for rva, noff, _, _ in methods:
            addr = base + rva - ROOT + ROOT  # absolute
            addr = base + rva
            buf = read(f, addr, 16)
            h = method_header(buf)
            if h:
                ok += 1
        if ok >= len(methods) - 1:
            best = (base, meta_rva, ok)
            break
    if not best:
        print("no base found")
        return
    base, meta_rva, ok = best
    print(f"BASE=0x{base:x} meta_rva=0x{meta_rva:x} ({ok}/{len(methods)} method headers valid)")

    us_root, us_size = streams["#US"]
    str_root, _ = streams["#Strings"]

    for i, (rva, noff, _, _) in enumerate(methods):
        addr = base + rva
        buf = read(f, addr, 0x40)
        h = method_header(buf)
        if not h:
            print(f"\n=== [{i}] rva=0x{rva:x} @0x{addr:x} header invalid ===")
            continue
        hs, cs, _ = h
        il = read(f, addr + hs, min(cs, 0x4000))
        nm_off = noff
        f.seek(str_root + nm_off)
        nm = f.read(48).split(b"\x00")[0].decode("latin-1", "replace")
        print(f"\n=== [{i}] {nm!r} rva=0x{rva:x} codesize={cs} @0x{addr + hs:x} ===")
        # quick ldstr token extraction
        j = 0
        toks = []
        while j < len(il) - 4:
            if il[j] == 0x72:  # ldstr
                tok = struct.unpack_from("<I", il, j + 1)[0]
                if 0x70000000 <= tok < 0x70000000 + us_size:
                    toks.append(tok - 0x70000000)
            j += 1
        if toks:
            print(f"   ldstr offsets: {toks}")
        try:
            from dncil.cil.body import CilMethodBody
            from dncil.cil.error import MethodBodyFormatError
            from dncil.clr.token import Token, StringToken, InvalidToken
            from dncil.cil.body.reader import CilMethodBodyReaderBase

            class Reader(CilMethodBodyReaderBase):
                def __init__(self, data):
                    self.data = data
                    self.off = 0
                def read(self, n):
                    r = self.data[self.off:self.off + n]
                    self.off += n
                    return r
                def tell(self):
                    return self.off
                def seek(self, o):
                    self.off = o
                    return o

            body = CilMethodBody(Reader(il))
            for insn in body.instructions:
                op = str(insn.opcode)
                operand = ""
                if isinstance(insn.operand, StringToken):
                    operand = f"us[0x{insn.operand.rid:x}]"
                elif insn.operand is not None:
                    operand = str(insn.operand)
                print(f"   IL_{insn.offset - body.offset:04x}: {op} {operand}")
        except Exception as e:
            print(f"   (dncil fail: {e})")
            print("   hex:", il[:96].hex())

if __name__ == "__main__":
    main()
