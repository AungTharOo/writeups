# CSG 2026 Script Kits — Battle Pack

Pre-made, competition-legal scripts (created BEFORE the competition — explicitly allowed
as "Scripts created before the competition"). All pure Python 3 / Bash, stdlib +
`pycryptodome` (install on your Kali: `pip install pycryptodome`).

```
scripts/
├── crypto_kit/      rsa_attack / xor_brute / vigenere_solver / padding_oracle / decrypt_hunt
├── stego_kit/       lsb_extract / trailing_data / stego_triage.sh / pdf_hunt.sh / qr_hunt.py
├── network_kit/     pcap_reassemble / usb_hid_decode / pcap_creds.sh / can_triage.py
└── forensics_kit/   vol_triage / carve_module / il_dump / aes_key_hunt / dump_key_scan /
                     exif_harvest / ssh_key_recovery.sh / fat_recover.sh
```

## v2 — hint-driven additions (approved-list intelligence)

The approved tools list Category column leaks the challenge plan. New scripts are the
automation for the loudest hints:

| Hint on the list | Predicted challenge | Script |
|---|---|---|
| qpdf → "Stegano", PDF Viewer → Stegano | PDF stego (hidden streams/objects/attachments) | `stego_kit/pdf_hunt.sh` |
| OpenSSH-Session-Key-Recovery (vol3 plugin) | memory dump → SSH keys → decrypt SSH pcap | `forensics_kit/ssh_key_recovery.sh` |
| can-utils + cannelloni ("Network") | CAN bus / automotive / odometer | `network_kit/can_triage.py` |
| ZBar → "Stegano" | QR hidden in planes / video frames | `stego_kit/qr_hunt.py` |
| fsck.fat → "Reversing", xz → Forensic | corrupted FAT image repair + undelete | `forensics_kit/fat_recover.sh` |

Every script has `--help` (bash ones print usage). The forensics_kit scripts were
validated LIVE against the CSG 2025 combined challenge (see SOLVE_LOG in the handbook);
`can_triage.py` was smoke-tested on synthetic candump logs.
