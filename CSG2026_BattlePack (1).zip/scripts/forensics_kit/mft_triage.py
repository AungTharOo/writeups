#!/usr/bin/env python3
"""
mft_triage.py - NTFS $MFT triage for CTF forensics (battle-tested on CSG2025 evidence.zip)

Modes:
  --find-created "2025-09-10 08:18:20.06"   find records whose FILE_NAME create time matches
                                            (UTC; try --tz-hours for local-time authors)
  --name-substr flag                        case-insensitive filename hunt
  --rec 12345                               dump one MFT record verbosely
  --deleted                                 list deleted files (not in use)
  --stats                                   quick counters

Usage:
  python3 mft_triage.py '$MFT' --find-created "2025-09-10 08:18:20" --tz-hours 0 --window 1.5
  python3 mft_triage.py '$MFT' --name-substr flag --limit 50
"""
import struct, argparse, mmap, sys, datetime, os

EPOCH = datetime.datetime(1601, 1, 1)

def ft_to_dt(ft: int):
    if ft == 0 or ft > 0x0200000000000000 or ft < 0:
        return None
    try:
        return EPOCH + datetime.timedelta(microseconds=ft // 10)
    except OverflowError:
        return None

ATTR_TYPES = {0x10: "$STANDARD_INFORMATION", 0x30: "$FILE_NAME", 0x40: "$OBJECT_ID",
              0x50: "$SECURITY_DESCRIPTOR", 0x60: "$VOLUME_NAME", 0x70: "$VOLUME_INFORMATION",
              0x80: "$DATA", 0x90: "$INDEX_ROOT", 0xA0: "$INDEX_ALLOCATION", 0xB0: "$BITMAP",
              0x100: "$LOGGED_UTILITY_STREAM"}

def apply_fixup(rec: bytes, rec_size: int):
    """Apply update-sequence fixup. Returns corrected record bytes or None."""
    if len(rec) < rec_size:
        rec = rec + b"\x00" * (rec_size - len(rec))
    usa_off, usa_count = struct.unpack_from("<HH", rec, 0x04)
    if usa_off == 0 or usa_count == 0:
        return rec
    seq = struct.unpack_from("<H", rec, usa_off)[0]
    fixups = struct.unpack_from("<" + "H" * (usa_count - 1), rec, usa_off + 2)
    sector = 512
    for i, fix in enumerate(fixups):
        end = (i + 1) * sector - 2
        if end + 2 > rec_size:
            break
        val = struct.unpack_from("<H", rec, end)[0]
        if val != seq:
            return None  # corrupt record
        struct.pack_into("<H", rec, end, fix)
    return rec

def parse_attributes(rec: bytes, rec_off: int):
    """Yield (attr_type, attr_name, resident, value_bytes, data_runs_info)."""
    first_attr = struct.unpack_from("<H", rec, 0x14)[0]
    off = rec_off + first_attr
    end_of_rec = rec_off + struct.unpack_from("<I", rec, 0x1C)[0]
    end_of_rec = min(end_of_rec, rec_off + len(rec))
    while off + 4 <= end_of_rec:
        try:
            atype, alen = struct.unpack_from("<II", rec, off)
        except struct.error:
            break
        if atype == 0xFFFFFFFF or atype == 0 or alen < 3 or off + alen > end_of_rec:
            break
        nonres = rec[off + 8]
        name_len = rec[off + 9]
        name_off = struct.unpack_from("<H", rec, off + 10)[0]
        aname = ""
        if name_len and off + name_off + name_len * 2 <= len(rec):
            aname = rec[off + name_off: off + name_off + name_len * 2].decode("utf-16-le", "replace")
        val = b""
        runs = None
        if nonres == 0:
            vsize, voff = struct.unpack_from("<IH", rec, off + 16)
            if off + voff + vsize <= len(rec):
                val = rec[off + voff: off + voff + vsize]
        else:
            real_size = struct.unpack_from("<Q", rec, off + 0x30)[0]
            run_off = struct.unpack_from("<H", rec, off + 0x20)[0]
            runs = (off + run_off, real_size)
        yield atype, aname, nonres == 0, val, runs
        off += alen

def parse_fn_value(val: bytes):
    """$FILE_NAME value -> dict"""
    if len(val) < 66:
        return None
    parent_ref = struct.unpack_from("<Q", val, 0)[0] & 0x0000FFFFFFFFFFFF
    c, m, mm, a = struct.unpack_from("<QQQQ", val, 8)
    nlen = val[64]
    ns = val[65]
    name = val[66:66 + nlen * 2].decode("utf-16-le", "replace") if nlen else ""
    return dict(parent=parent_ref, created=c, modified=m, mft_mod=mm, accessed=a,
                name=name, ns=ns)

def parse_si_value(val: bytes):
    if len(val) < 32:
        return None
    c, m, mm, a = struct.unpack_from("<QQQQ", val, 0)
    return dict(created=c, modified=m, mft_mod=mm, accessed=a)

def iter_records(mm, rec_size=1024):
    size = mm.size()
    n = 0
    for off in range(0, size - rec_size + 1, rec_size):
        magic = mm[off:off + 4]
        if magic == b"FILE":
            n += 1
            rec = apply_fixup(bytearray(mm[off:off + rec_size]), rec_size)
            yield off // rec_size, rec
        elif magic == b"BAAD":
            n += 1
            yield off // rec_size, None
    sys.stderr.write(f"[i] scanned {n} FILE-magic records\n")

def parse_record(recnum: int, rec: bytes):
    if rec is None:
        return None
    flags = struct.unpack_from("<H", rec, 0x16)[0]
    seq = struct.unpack_from("<H", rec, 0x10)[0]
    rec_entry = {"num": recnum, "seq": seq, "in_use": bool(flags & 1),
                 "is_dir": bool(flags & 2), "names": [], "si": None, "attrs": []}
    for atype, aname, resident, val, runs in parse_attributes(rec, 0):
        if atype == 0x30:
            fn = parse_fn_value(val)
            if fn:
                rec_entry["names"].append(fn)
        elif atype == 0x10:
            si = parse_si_value(val)
            if si:
                rec_entry["si"] = si
        elif atype == 0x80:
            tag = f"$DATA:{aname or '(unnamed)'}"
            if resident:
                rec_entry["attrs"].append((tag, f"resident {len(val)} bytes"))
            elif runs:
                rec_entry["attrs"].append((tag, f"nonresident {runs[1]} bytes"))
    return rec_entry

def parse_runlist(buf: bytes, off: int):
    """Decode NTFS data runs -> [(lcn_offset, clusters), ...] as LCN deltas."""
    runs = []
    lcn = 0
    i = off
    while i < len(buf):
        h = buf[i]
        if h == 0:
            break
        len_n = h & 0xF
        off_n = h >> 4
        if len_n == 0 or off_n > 8 or i + 1 + len_n + off_n > len(buf):
            break
        length = int.from_bytes(buf[i + 1:i + 1 + len_n], "little")
        ob = buf[i + 1 + len_n:i + 1 + len_n + off_n]
        delta = int.from_bytes(ob, "little", signed=(ob[-1] & 0x80) != 0)
        lcn += delta
        runs.append((lcn, length))
        i += 1 + len_n + off_n
    return runs

def get_record_raw(mm, recnum, rec_size=1024):
    off = recnum * rec_size
    if off + rec_size > mm.size():
        return None
    magic = mm[off:off + 4]
    if magic != b"FILE":
        return None
    return apply_fixup(bytearray(mm[off:off + rec_size]), rec_size)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mftfile")
    ap.add_argument("--find-created", dest="find_created")
    ap.add_argument("--tz-hours", type=float, default=0.0)
    ap.add_argument("--window", type=float, default=1.5, help="seconds tolerance")
    ap.add_argument("--name-substr", dest="name_substr")
    ap.add_argument("--rec", type=int)
    ap.add_argument("--extract", type=int, metavar="RECNUM",
                    help="dump resident $DATA (and $DATA named streams) of record to files")
    ap.add_argument("--show-runs", type=int, metavar="RECNUM",
                    help="decode nonresident $DATA runlist of record")
    ap.add_argument("--parent", type=lambda x: int(x, 0), metavar="RECNUM",
                    help="list all files whose FILE_NAME parent = RECNUM")
    ap.add_argument("--deleted", action="store_true")
    ap.add_argument("--grep-data", dest="grep_data", default=None,
                    help="regex: scan resident $DATA values of every record")
    ap.add_argument("--limit", type=int, default=100)
    ap.add_argument("--stats", action="store_true")
    args = ap.parse_args()

    f = open(args.mftfile, "rb")
    mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

    if args.extract is not None or args.show_runs is not None:
        recnum = args.extract if args.extract is not None else args.show_runs
        rec = get_record_raw(mm, recnum)
        if rec is None:
            sys.exit(f"record {recnum} not found / not FILE")
        for atype, aname, resident, val, runs in parse_attributes(rec, 0):
            if atype != 0x80:
                continue
            tag = (aname or "unnamed").strip("()").replace(":", "_")
            if resident:
                out = f"rec{recnum}_{tag}.bin"
                with open(out, "wb") as o:
                    o.write(val)
                print(f"[extract] resident {aname or '(unnamed)'}: {len(val)} bytes -> {out}")
                print("---- preview ----")
                print(val[:400].decode("utf-8", "replace"))
            else:
                run_off, real = runs
                rr = parse_runlist(rec, run_off) if run_off < len(rec) else []
                print(f"[runs] {aname or '(unnamed)'}: real_size={real}")
                tot = 0
                for lcn, cl in rr:
                    print(f"       lcn={lcn} clusters={cl}")
                    tot += cl
                print(f"       total_clusters={tot}")
        return
    found = 0
    stats = dict(total=0, in_use=0, dirs=0, deleted=0)

    # target timestamps for --find-created (author may have used local time)
    targets = []
    if args.find_created:
        base = args.find_created
        fmts = ["%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"]
        dt = None
        for fmt in fmts:
            try:
                dt = datetime.datetime.strptime(base, fmt)
                break
            except ValueError:
                pass
        if dt is None and "." in base:  # 7-digit 100ns precision -> truncate to 6
            head, frac = base.rsplit(".", 1)
            for fmt in fmts:
                try:
                    dt = datetime.datetime.strptime(f"{head}.{frac[:6]}", fmt)
                    break
                except ValueError:
                    pass
        if dt is None:
            sys.exit("bad date format")
        for delta_h in (0.0, -args.tz_hours, args.tz_hours):
            targets.append(dt + datetime.timedelta(hours=delta_h))

    import re
    grepper = re.compile(args.grep_data.encode() if args.grep_data else b"X\x00X\x00X\x00X\x00X\x00X\x00X\x00X\x00X\x00X\x00X\x00X\x00X", re.IGNORECASE)
    for recnum, rec in iter_records(mm):
        stats["total"] += 1
        e = parse_record(recnum, rec)
        if e is None:
            continue
        if args.grep_data and rec is not None:
            for atype, aname, resident, val, runs in parse_attributes(rec, 0):
                if resident and val and atype not in (0x10, 0x30):
                    m = grepper.search(val)
                    if m:
                        s = max(0, m.start() - 80)
                        ctx = val[s:m.end() + 80]
                        print(f"[DATA] rec#{recnum} attr={ATTR_TYPES.get(atype, hex(atype))}:{aname or '(unnamed)'} "
                              f"match={m.group()!r}")
                        print("   ctx:", ctx[:260])
                        found += 1
                        if found >= args.limit:
                            break
        if e["in_use"]:
            stats["in_use"] += 1
        else:
            stats["deleted"] += 1
        if e["is_dir"]:
            stats["dirs"] += 1

        if args.rec is not None and recnum == args.rec:
            print(f"== record {recnum} ==")
            print(f"  in_use={e['in_use']} dir={e['is_dir']} seq={e['seq']}")
            si = e["si"]
            if si:
                for k in ("created", "modified", "mft_mod", "accessed"):
                    print(f"  SI.{k}: {ft_to_dt(si[k])} UTC  (raw 0x{si[k]:x})")
            for fn in e["names"]:
                print(f"  FN '{fn['name']}' ns={fn['ns']} parent={fn['parent'] & 0xFFFFFFFFFFFF}")
                for k in ("created", "modified", "mft_mod", "accessed"):
                    print(f"     {k}: {ft_to_dt(fn[k])} UTC")
            for tag, desc in e["attrs"]:
                print(f"  {tag}: {desc}")

        for fn in e["names"]:
            if args.parent is not None and (fn["parent"] & 0xFFFFFFFFFFFF) == args.parent:
                print(f"[CHILD] rec#{recnum} in_use={e['in_use']} dir={e['is_dir']} "
                      f"name='{fn['name']}' created={ft_to_dt(fn['created'])} UTC "
                      f"attrs={e['attrs']}")
                found += 1
            cdt = ft_to_dt(fn["created"])
            if args.find_created and cdt:
                for tgt in targets:
                    if abs((cdt - tgt).total_seconds()) <= args.window:
                        print(f"[HIT] rec#{recnum} in_use={e['in_use']} dir={e['is_dir']} "
                              f"name='{fn['name']}' parent={fn['parent'] & 0xFFFFFFFFFFFF} "
                              f"created={cdt} UTC")
                        print(f"      record seq={e['seq']} attrs={e['attrs']}")
                        found += 1
            if args.name_substr and args.name_substr.lower() in fn["name"].lower():
                print(f"[NAME] rec#{recnum} in_use={e['in_use']} dir={e['is_dir']} "
                      f"name='{fn['name']}' parent={fn['parent'] & 0xFFFFFFFFFFFF} "
                      f"created={ft_to_dt(fn['created'])} UTC")
                found += 1
        if args.deleted and not e["in_use"] and e["names"]:
            for fn in e["names"]:
                print(f"[DEL] rec#{recnum} name='{fn['name']}' created={ft_to_dt(fn['created'])} UTC")
                found += 1
        if found >= args.limit and (args.name_substr or args.deleted):
            break

    if args.stats:
        print("stats:", stats)
    if args.find_created and found == 0:
        print("[!] no match - widen --window, check --tz-hours (author may quote local time)")

if __name__ == "__main__":
    main()
