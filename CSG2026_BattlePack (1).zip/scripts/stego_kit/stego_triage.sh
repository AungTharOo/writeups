#!/usr/bin/env bash
# stego_triage.sh — one-command image stego pipeline (PNG/JPG/BMP/GIF)
# usage: ./stego_triage.sh image.png
F="${1:?usage: ./stego_triage.sh image}"
echo "=== file/type/magic ==="; file "$F"; xxd "$F" | head -3
echo; echo "=== zsteg (PNG/BMP) ===";  zsteg -a "$F" 2>/dev/null | head -40
echo; echo "=== stegseek (JPG) ===";    stegseek "$F" --crack 2>/dev/null || true
echo; echo "=== binwalk ===";           binwalk "$F" 2>/dev/null | head -20
echo; echo "=== exiftool ===";          exiftool -a -u -g1 "$F" 2>/dev/null | head -30
echo; echo "=== structure check ===";   pngcheck -v "$F" 2>/dev/null || jpeginfo -c "$F" 2>/dev/null || true
echo; echo "=== trailing data ===";     python3 "$(dirname "$0")/trailing_data.py" "$F" 2>/dev/null || xxd "$F" | tail -5
echo; echo "=== QR peek ===";           zbarimg -q --raw "$F" 2>/dev/null || true
echo; echo "=== flag grep ===";         strings -a "$F" | grep -aiE "csg_flag|flag\{" | head
