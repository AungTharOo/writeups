#!/usr/bin/env python3
"""
can_triage.py — CAN bus log triage for CTF challenges
=====================================================
WHY THIS SCRIPT EXISTS (tool-hint intelligence):
  can-utils + cannelloni are BOTH on the approved list under category "Network".
  cannelloni (CAN-over-Ethernet tunnel) is far too niche to be listed "just in case"
  -> expect an automotive/CAN challenge: candump logs, an odometer/speedo to fake,
     or a flag ASCII-encoded across CAN frames.

USAGE
  python3 can_triage.py candump.log                 # full triage of a log
  python3 can_triage.py candump.log --id 0x17       # dump every payload of one ID
  python3 can_triage.py candump.log --flag          # only the flag-hunt part
  candump -L any can0 | python3 can_triage.py -     # live/read stdin (-L = log fmt)

INPUT FORMATS (auto-detected)
  candump log format:    (1700000000.123456) vcan0 123#DEADBEEF87654321
  candump default fmt:   vcan0  123   [8]  DE AD BE EF 87 65 43 21
  cannelloni bridging:   cannelloni -r <IP> -l <PORT> -I vcan0   # then candump vcan0
                         (create vcan first: ip link add dev vcan0 type vcan
                          && ip link set vcan0 up)

WHAT IT ANSWERS
  1. Which CAN IDs exist, how often (Hz), when they started/stopped
  2. Which bytes per ID are STATIC (constants) vs DYNAMIC (data/sensors)
  3. Counter bytes (incrementing values -> sequence/odometer candidates)
  4. ASCII-in-payload (flag smuggled as text across frames, most common CTF trick)
  5. Direct flag grep (CSG_FLAG / flag{ / CSG{) in payloads
"""
import sys, re, collections, argparse

FLAG_PAT = re.compile(rb"(?i)(csg_flag\{|flag\{|csg\{|ctf\{|[A-Za-z0-9_/+=]{6,})")

def parse_line(line):
    """Return (ts, iface, canid:int, data:bytes) or None."""
    line = line.strip()
    if not line:
        return None
    m = re.match(r"\(([\d.]+)\)\s+(\S+)\s+([0-9A-Fa-f]+)#([0-9A-Fa-f]*)", line)
    if m:  # log format
        return (float(m.group(1)), m.group(2), int(m.group(3), 16), bytes.fromhex(m.group(4)))
    # default format: iface  ID   [len]  DE AD BE EF ...
    m = re.match(r"(\S+)\s+([0-9A-Fa-f]{1,8})\s+\[\d+\]\s+((?:[0-9A-Fa-f]{2}\s*)+)", line)
    if m:
        return (None, m.group(1), int(m.group(2), 16), bytes.fromhex(m.group(3).replace(" ", "")))
    return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("logfile", help="candump log file or '-' for stdin")
    ap.add_argument("--id", help="show all payloads of this CAN ID (hex, 0x ok)")
    ap.add_argument("--flag", action="store_true", help="only run the flag hunt")
    args = ap.parse_args()

    fh = sys.stdin if args.logfile == "-" else open(args.logfile, "r", errors="replace")
    frames = []
    for ln in fh:
        p = parse_line(ln)
        if p and p[3]:
            frames.append(p)

    if not frames:
        print("[-] no CAN frames parsed — is this really a candump log?")
        print("    try: candump -L can0 > log.txt   (log format)")
        return

    # ---- flag hunt first (always first in CTF) -------------------------------
    print("=" * 62)
    print("FLAG HUNT  (ASCII across frames + raw grep)")
    print("=" * 62)
    hits = []
    # concatenate payloads per ID in time order, then grep
    for cid in sorted({f[2] for f in frames}):
        blob = b"".join(f[3] for f in frames if f[2] == cid)
        for m in re.finditer(rb"(?i)csg_flag\{[^}]{0,120}\}", blob):
            hits.append((cid, m.group(0).decode("latin1")))
        for m in FLAG_PAT.finditer(blob):
            s = m.group(0)
            if len(s) >= 6 and any(c in s for c in b"{_}") or b"CSG" in s.upper():
                hits.append((cid, s.decode("latin1")))
    # also sliding-window over the global stream (flag split across IDs)
    gblob = b"".join(f[3] for f in frames)
    for m in re.finditer(rb"(?i)csg_flag\{[^}]{0,80}\}", gblob):
        hits.append(("*stream*", m.group(0).decode("latin1")))
    for cid, s in hits:
        print(f"  [!] ID {cid:#x}: {s}")
    if not hits:
        print("  [.] no ASCII flag in payloads — check reversed order (per-ID, then global),")
        print("      byte-nibble swap, and non-ASCII encoding (see commands in handbook 4.8)")

    if args.flag:
        return

    if args.id:
        want = int(args.id, 16) if not args.id.lower().startswith("0x") else int(args.id, 16)
        for ts, _, cid, data in frames:
            if cid == want:
                print(f"{ts!r:>20}  {want:#04x}# {data.hex().upper()}  "
                      f"{''.join(chr(b) if 32 <= b < 127 else '.' for b in data)}")
        return

    # ---- per-ID statistics ----------------------------------------------------
    print()
    print("=" * 62)
    print(f"PER-ID STATS   ({len(frames)} frames, "
          f"{len({f[2] for f in frames})} unique IDs)")
    print("=" * 62)
    by_id = collections.defaultdict(list)
    for ts, _, cid, data in frames:
        by_id[cid].append((ts, data))

    t0 = min((f[0] for f in frames if f[0] is not None), default=None)
    t1 = max((f[0] for f in frames if f[0] is not None), default=None)
    span = (t1 - t0) or 1e-9

    rows = []
    for cid, items in sorted(by_id.items()):
        cnt = len(items)
        hz = cnt / span if t0 is not None else 0
        dlen = len(items[0][1])
        # per-byte dynamics: how many distinct values per byte position
        byte_var = []
        for pos in range(dlen):
            vals = {d[1][pos] for d in items if len(d[1]) > pos}
            byte_var.append(len(vals))
        static = "".join("S" if v <= 1 else "." for v in byte_var)
        # counter detection: a byte that (mostly) increments by 1
        counters = []
        for pos in range(dlen):
            seq = [d[1][pos] for d in items if len(d[1]) > pos]
            inc = sum(1 for a, b in zip(seq, seq[1:]) if (b - a) % 256 == 1)
            if cnt >= 4 and inc / (cnt - 1) > 0.8:
                counters.append(pos)
        rows.append((cnt, hz, cid, dlen, static, counters))
    rows.sort(reverse=True)
    print(f"{'count':>7} {'Hz':>7}  {'ID':>8}  {'len':>3}  {'S=static':<16} counters")
    for cnt, hz, cid, dlen, static, counters in rows[:40]:
        cstr = f"byte{counters}" if counters else ""
        print(f"{cnt:>7} {hz:>7.1f}  {cid:>8}  {dlen:>3}  {static:<16} {cstr}")

    # ---- analyst hints --------------------------------------------------------
    print()
    print("[HINTS]")
    print(" - RARE IDs (count <= 5): usually the challenge payload — dump with --id")
    print(" - 'S........' pattern: static first byte = message type, rest = data")
    print(" - counter byte = sequence number; gaps = lost frames (or deliberate)")
    print(" - odometer/speed challenges: value that ONLY increases -> try crafting")
    print("   frames with cansend:  cansend vcan0 <ID>#<payload>")
    print(" - try bit-stuffing artifacts: payloads that decode as 7-bit packed ASCII")
    print(" - ELM327/OBD-II PIDs: 0x0C=rpm 0x0D=speed 0x11=throttle 0x21/0x31 combos")

if __name__ == "__main__":
    main()
