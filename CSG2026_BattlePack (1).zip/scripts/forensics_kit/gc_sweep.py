#!/usr/bin/env python3
"""Sweep around each UTF-16 CSG_FLAG occurrence for surrounding string objects."""
import re, sys

DUMP = "/home/z/my-project/challenges/memdump.mem"
NEEDLE = "CSG_FLAG".encode("utf-16-le")

f = open(DUMP, "rb")
import mmap
mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

pos = 0
groups = []
while True:
    idx = mm.find(NEEDLE, pos)
    if idx < 0:
        break
    pos = idx + 2
    if groups and idx - groups[-1][-1] < 0x200000:
        groups[-1].append(idx)
    else:
        groups.append([idx])

print(f"groups: {[len(g) for g in groups]}")
pat = re.compile(rb"(?:[\x20-\x7e]\x00){4,}")
for gi, g in enumerate(groups):
    lo = max(0, g[0] - 0x3000)
    hi = g[-1] + 0x3000
    blob = mm[lo:hi]
    strs = [(m.start() + lo, m.group().decode("utf-16-le")) for m in pat.finditer(blob)]
    uniq = []
    seen = set()
    for off, s in strs:
        if s in seen:
            continue
        seen.add(s)
        uniq.append((off, s))
    print(f"\n===== group {gi} @0x{g[0]:x} x{len(g)} - {len(uniq)} uniq strings =====")
    for off, s in uniq[:80]:
        print(f"  @0x{off:x}: {s!r}")
