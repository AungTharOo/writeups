#!/usr/bin/env python3
"""
carve_module.py — Carve a module (PE/DLL/EXE) out of a Windows minidump (.dmp).
Works on MINIDUMP format (MDMP) using ModuleListStream + Memory64ListStream.

Usage:
  python3 carve_module.py dump.dmp dllname.dll [-o out.dll]
  python3 carve_module.py dump.dmp --list
"""
import struct, sys, os, argparse

def read_dir(data):
    sig, ver, n, dir_rva = struct.unpack_from("<4sIII", data, 0)
    assert sig == b"MDMP", "not a minidump"
    streams = {}
    for i in range(n):
        st, sz, rva = struct.unpack_from("<III", data, dir_rva + i*12)
        streams.setdefault(st, (sz, rva))
    return streams

def parse_modules(data, streams):
    """ModuleListStream(4): count + MINIDUMP_MODULE[108 bytes each]:
    ULONG64 BaseOfImage; ULONG32 SizeOfImage; ULONG32 CheckSum; ULONG32 TimeDateStamp;
    RVA ModuleNameRva(4); VS_FIXEDFILEINFO(52); MINIDUMP_LOCATION_DESCRIPTOR CvRecord(8);
    MiscRecord(8); ULONG64 Reserved0; Reserved1  => offsets: base@0 size@8 name_rva@20"""
    sz, rva = streams[4]
    (n,) = struct.unpack_from("<I", data, rva)
    mods = []
    for m in range(n):
        base = rva + 4 + m*108
        mbase, msize, mchk, mts, name_rva = struct.unpack_from("<QIIII", data, base)
        (ln,) = struct.unpack_from("<I", data, name_rva)
        name = data[name_rva+4:name_rva+4+ln].decode("utf-16-le", "replace")
        mods.append((mbase, msize, name))
    return mods

def parse_mem64(data, streams):
    """Memory64ListStream(9): ULONG64 count; ULONG64 base_rva;
    then count * (ULONG64 start_of_memory_range, ULONG64 data_size)."""
    sz, rva = streams[9]
    (count,) = struct.unpack_from("<Q", data, rva)
    (base_rva,) = struct.unpack_from("<Q", data, rva+8)
    ranges = []
    off = rva + 16
    cur = base_rva
    for i in range(count):
        start, size = struct.unpack_from("<QQ", data, off + i*16)
        ranges.append((start, size, cur))
        cur += size
    return ranges

def read_at(ranges, data, addr, size):
    """Read `size` bytes at virtual `addr` from the dump."""
    for start, rsize, file_off in ranges:
        if start <= addr < start + rsize:
            delta = addr - start
            avail = min(size, rsize - delta)
            return data[file_off+delta : file_off+delta+avail]
    return b""

def carve(data, ranges, base, size):
    """Reassemble module image from possibly non-contiguous ranges."""
    out = bytearray()
    for i in range(size):
        pass  # fast path below
    # contiguous read in chunks
    out = bytearray()
    pos = base
    end = base + size
    while pos < end:
        chunk = read_at(ranges, data, pos, min(1<<20, end-pos))
        if not chunk:
            out += b"\x00" * min(4096, end-pos)
            pos += 4096
        else:
            out += chunk
            pos += len(chunk)
    return bytes(out)

def unmap_pe(img):
    """Convert a memory-mapped PE image back to a file-aligned PE."""
    if img[:2] != b"MZ":
        raise ValueError("no MZ")
    e_lfanew = struct.unpack_from("<I", img, 0x3C)[0]
    assert img[e_lfanew:e_lfanew+4] == b"PE\x00\x00"
    nsec = struct.unpack_from("<H", img, e_lfanew+6)[0]
    opt_size = struct.unpack_from("<H", img, e_lfanew+20)[0]
    sec0 = e_lfanew + 24 + opt_size
    # headers: copy from image start to end of section table
    hdr_end = sec0 + nsec*40
    file_align = struct.unpack_from("<I", img, e_lfanew+24+36)[0] or 0x200
    out = bytearray(img[:hdr_end])
    for s in range(nsec):
        sh = sec0 + s*40
        name = img[sh:sh+8].rstrip(b"\x00")
        vsize, va, rawsize, rawptr = struct.unpack_from("<IIII", img, sh+8)
        print(f"    section {name.decode(errors='replace'):8s} va={va:#x} vsize={vsize:#x} raw={rawptr:#x} rawsize={rawsize:#x}")
        data = img[va:va+max(vsize, rawsize)]
        if len(data) < rawsize:
            data += b"\x00" * (rawsize - len(data))
        if rawptr + rawsize > len(out):
            out.extend(b"\x00" * (rawptr - len(out)))
        out[rawptr:rawptr+rawsize] = data[:rawsize]
    return bytes(out)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dump")
    ap.add_argument("module", nargs="?", help="substring of module name to carve")
    ap.add_argument("-o", "--out", default=None)
    ap.add_argument("--unmap", action="store_true", help="rebuild as file-aligned PE")
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args()

    data = open(args.dump, "rb").read()
    streams = read_dir(data)
    mods = parse_modules(data, streams)
    ranges = parse_mem64(data, streams)
    print(f"[*] {len(mods)} modules, {len(ranges)} memory ranges")

    if args.list or not args.module:
        for mbase, msize, name in mods:
            print(f"  {mbase:#018x} {msize:>10,}  {name}")
        return

    hit = [m for m in mods if args.module.lower() in m[2].lower()]
    if not hit:
        sys.exit(f"[!] module {args.module!r} not found")
    for mbase, msize, name in hit:
        img = carve(data, ranges, mbase, msize)
        if img[:2] != b"MZ":
            print(f"[!] {name}: no MZ at base {mbase:#x} (managed images may be unmapped) — searching for MZ within ±0x2000")
            off = img.find(b"MZ", 0, 0x4000)
            if off < 0:
                print("[!] no MZ found, dumping raw anyway")
                off = 0
            img = img[off:]
        if args.unmap:
            print("[*] unmap (file-align) sections:")
            img = unmap_pe(img)
        out = args.out or os.path.basename(name) or "carved.bin"
        with open(out, "wb") as f:
            f.write(img)
        print(f"[+] carved {len(img):,}B from {name} -> {out}")

if __name__ == "__main__":
    main()
