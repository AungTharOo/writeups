#!/usr/bin/env python3
"""
qr_hunt.py — QR / barcode hunt with preprocessing ladder
========================================================
WHY THIS SCRIPT EXISTS (tool-hint intelligence):
  ZBar is on the approved list with category "Stegano" — a QR code is expected,
  and in stego challenges it is NEVER a clean QR. It hides in bit planes, gets
  inverted, scaled down, split into tiles, or buried in video frames.
  zbarimg alone fails; this script runs the whole preprocessing ladder for you.

USAGE
  python3 qr_hunt.py img.png [img2.png ...]      # images: ladder per file
  python3 qr_hunt.py video.mp4 --every 0.25      # sample 1 frame / 0.25 s (needs cv2)
  python3 qr_hunt.py frames_dir/                 # directory of extracted frames
  python3 qr_hunt.py img.png --split 4           # also try 4x4 tile reassembly

REQUIRES (all approved / preinstalled): zbarimg (zbar), Python PIL + numpy, cv2 optional
PIPELINE PER IMAGE
  raw -> inverted -> 2x/4x upscale -> grayscale autocontrast -> hard threshold
  -> 1px white border -> per-bit-plane extracts (PNG only) -> tile split reassemble
Prints every decoded payload; QR payload is often ANOTHER layer (base64/xor -> CyberChef).
"""
import sys, os, subprocess, tempfile, argparse

def zbar(path):
    try:
        r = subprocess.run(["zbarimg", "--raw", "-q", path],
                           capture_output=True, text=True, timeout=30)
        out = (r.stdout or "").strip()
        return out.splitlines() if out else []
    except Exception:
        return []

def variants(img):
    """Yield (label, PIL.Image) preprocessing variants."""
    from PIL import Image, ImageOps
    g = img.convert("L")
    yield ("gray", g)
    yield ("invert", ImageOps.invert(g))
    yield ("autocontrast", ImageOps.autocontrast(g))
    yield ("invert+auto", ImageOps.autocontrast(ImageOps.invert(g)))
    # upscale small images (QR minimum module size matters)
    w, h = g.size
    if max(w, h) < 1200:
        for s in (2, 4):
            yield (f"scale{x}" if False else f"x{s}", g.resize((w * s, h * s), Image.NEAREST))
    # hard threshold sweep
    for t in (64, 128, 192):
        yield (f"thresh{t}", g.point(lambda p, t=t: 255 if p > t else 0))
    # white border padding (QR hugging the edge fails to localize)
    yield ("border", ImageOps.expand(g, border=max(8, min(w, h) // 20), fill=255))
    yield ("border+inv", ImageOps.expand(ImageOps.invert(g), border=max(8, min(w, h) // 20), fill=255))

def try_all(path, split=0):
    from PIL import Image
    results = []
    try:
        img = Image.open(path)
        img.load()
    except Exception as e:
        print(f"[-] {path}: {e}")
        return results
    for label, v in variants(img):
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tf:
            v.save(tf.name)
            hits = zbar(tf.name)
        if hits:
            print(f"  [+] {os.path.basename(path)} [{label}]: {hits}")
            results.extend(hits)
        os.unlink(tf.name)
        if results:
            break  # found it — stop the ladder
    # bit-plane hunt (stego: QR lives in bit 0 of a channel)
    if not results and path.lower().endswith((".png", ".bmp", ".tif", ".tiff")):
        import numpy as np
        arr = np.array(img.convert("RGB"))
        for ch, cname in enumerate("RGB"):
            for bit in range(3):
                plane = ((arr[:, :, ch] >> bit) & 1) * 255
                pim = Image.fromarray(plane.astype("uint8"))
                with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tf:
                    pim.save(tf.name)
                    hits = zbar(tf.name)
                if hits:
                    print(f"  [+] {os.path.basename(path)} [{cname} bit{bit}]: {hits}")
                    results.extend(hits)
                os.unlink(tf.name)
                if results:
                    return results
    # tile split reassembly (QR cut into pieces, order shuffled)
    if not results and split:
        from PIL import Image
        w, h = img.size
        tiles = []
        for r in range(split):
            for c in range(split):
                tiles.append(img.crop((c * w // split, r * h // split,
                                       (c + 1) * w // split, (r + 1) * h // split)))
        import itertools
        for perm in itertools.permutations(range(split * split)):
            if perm == tuple(range(split * split)):
                continue
            canvas = Image.new("RGB", (w, h), "white")
            for idx, tnum in enumerate(perm):
                r, c = divmod(idx, split)
                canvas.paste(tiles[tnum], (c * w // split, r * h // split))
            if zbar_temp(canvas):
                print(f"  [+] {os.path.basename(path)} [tiles perm {perm}]")
                results.append("tiled-qr (open reassembled image for payload)")
                return results
    return results

def zbar_temp(pil_img):
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tf:
        pil_img.save(tf.name)
        hits = zbar(tf.name)
    os.unlink(tf.name)
    return hits

def video_frames(path, every):
    try:
        import cv2
    except ImportError:
        print("[-] cv2 not installed: pip install opencv-python-headless (allowed, non-AI)")
        return []
    cap = cv2.VideoCapture(path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    step = max(1, int(fps * every))
    out = []
    i = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if i % step == 0:
            fn = f"/tmp/qrframe_{i:06d}.png"
            cv2.imwrite(fn, frame)
            out.append(fn)
        i += 1
    cap.release()
    print(f"[*] sampled {len(out)} frames (every {every}s) -> /tmp/qrframe_*.png")
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--every", type=float, default=0.5, help="video sampling interval (s)")
    ap.add_argument("--split", type=int, default=0, help="try NxN tile reassembly (slow!)")
    args = ap.parse_args()

    files = []
    for p in args.paths:
        if os.path.isdir(p):
            files += sorted(os.path.join(p, f) for f in os.listdir(p))
        elif p.lower().endswith((".mp4", ".mkv", ".avi", ".mov", ".webm", ".gif")):
            files += video_frames(p, args.every)
        else:
            files.append(p)

    found = []
    for f in files:
        r = try_all(f, split=args.split)
        if r:
            found += r
            if not f.lower().endswith((".mp4", ".mkv", ".avi", ".mov", ".webm")):
                continue
    if not found:
        print("[!] Nothing decoded. Next moves:")
        print("    - StegSolve: Data Extract R/G/B bit0, row/col order -> save plane -> retry")
        print("    - QR pieces as SEPARATE images? scan every extracted frame/object")
        print("    - payload of a QR is often another layer: base64 / hex / rot13 / URL")
        print("    - aztec/data-matrix: drop -Sqrcode.enable restriction (zbarimg auto)")

if __name__ == "__main__":
    main()
