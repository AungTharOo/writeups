#!/usr/bin/env python3
"""Sweep a memory region for printable UTF-16LE strings (GC heap string objects)."""
import sys, re

DUMP = "/home/z/my-project/challenges/memdump.mem"
CENTER = int(sys.argv[1], 0) if len(sys.argv) > 1 else 0x158910
RADIUS = int(sys.argv[2], 0) if len(sys.argv) > 2 else 0x40000
MINLEN = int(sys.argv[3]) if len(sys.argv) > 3 else 6

f = open(DUMP, "rb")
start = max(0, CENTER - RADIUS)
f.seek(start)
blob = f.read(2 * RADIUS)

pat = re.compile(rb"(?:[\x20-\x7e]\x00){%d,}" % MINLEN)
seen = set()
for m in pat.finditer(blob):
    s = m.group().decode("utf-16-le")
    if s in seen:
        continue
    seen.add(s)
    print(f"@0x{start + m.start():x}: {s!r}")
