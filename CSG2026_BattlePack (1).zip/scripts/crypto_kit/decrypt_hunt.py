#!/usr/bin/env python3
"""Wide AES/3DES combo hunt for the CSG 8553 response blob."""
import base64, hashlib, itertools
from Crypto.Cipher import AES, DES3, ARC4

CT = base64.b64decode("1KeGOcMvvKpPbxrNRdyqJmSGh3j+ZCvIT5RKk6lTBkSGBYSYrX7dy3Q/E8wVuQAXNFMs978T1A4qyx7EeX9fvg==")
H1 = bytes.fromhex("2a5b05310e08081f2b3405031134372a073c1f1c371a2e1c09303b4308393219")
H2 = bytes.fromhex("252e0a0a3a1f291c1b343b39212b3c11013d312f08315158")
B1 = base64.b64decode("NzM4NTk2MTI2MzU4LXNrOTBlaHZsbWRyOXE=")  # 738596126358-sk90ehvlmdr9q
B2 = base64.b64decode("MTRzYzllZWlmN3VldXJiN2s3bg==")        # 14sc9eeif7ueurb7k7n
B3 = base64.b64decode("R09DU1BYLTVNN0pEOGQzbE5v")            # GOCSPX-5M7JD8d3lNo
B4 = base64.b64decode("YjQ4dTJSWDZoVWU=")                    # b48u2RX6hUe
B5 = base64.b64decode("UktETDVP")                            # RKDL5O

def xor(a, b): return bytes(x ^ b[i % len(b)] for i, x in enumerate(a))

keys = {}
def addk(n, k):
    if len(k) in (16, 24, 32) and k not in keys.values(): keys[n] = k

addk("H1", H1); addk("H2", H2)
for i, s in enumerate(["simplekey", "complekey"]):
    addk(f"sha256({s})", hashlib.sha256(s.encode()).digest())
    addk(f"md5({s})", hashlib.md5(s.encode()).digest())
addk("md5(H1)", hashlib.md5(H1).digest()); addk("md5(H2)", hashlib.md5(H2).digest())
addk("sha256(H1)", hashlib.sha256(H1).digest()); addk("sha256(H2)", hashlib.sha256(H2).digest())
addk("B1", B1); addk("B2", B2); addk("B3", B3); addk("B4", B4)
addk("md5(B1)", hashlib.md5(B1).digest()); addk("md5(B2)", hashlib.md5(B2).digest())
addk("H1^simplekey", xor(H1, b"simplekey")); addk("H2^simplekey", xor(H2, b"simplekey"))
addk("H1^complekey", xor(H1, b"complekey")); addk("H2^complekey", xor(H2, b"complekey"))
addk("sha256(B1)", hashlib.sha256(B1).digest())
addk("sha256(B2)", hashlib.sha256(B2).digest())
addk("H2+pad24", (H2 + b"\x00"*24)[:24])

ivs = {"zeros16": bytes(16)}
for i in range(len(H1)-15): ivs[f"H1[{i}:]"] = H1[i:i+16]
for i in range(len(H2)-15): ivs[f"H2[{i}:]"] = H2[i:i+16]
ivs["CT[:16]"] = CT[:16]
ivs["md5(simplekey)"] = hashlib.md5(b"simplekey").digest()
ivs["md5(complekey)"] = hashlib.md5(b"complekey").digest()
ivs["B4+pad"] = (B4 + b"\x00"*16)[:16]
ivs["B5+pad"] = (B5 + b"\x00"*16)[:16]

def hits(pt):
    if b"CSG" in pt or b"flag" in pt.lower() or b"FLAG" in pt: return True
    pr = sum(1 for b in pt if 32 <= b < 127 or b in (9, 10, 13))
    return pr / len(pt) > 0.85

found = []
for kn, k in keys.items():
    for ivn, iv in ivs.items():
        for mode, mname in [(AES.MODE_CBC, "CBC"), (AES.MODE_CFB, "CFB"), (AES.MODE_OFB, "OFB")]:
            if len(iv) != 16: continue
            for data, dtag in [(CT, "full"), (CT[16:], "skipblk")]:
                try:
                    c = AES.new(k, mode, iv=iv)
                    pt = c.decrypt(data)
                    if hits(pt): found.append((f"{kn} AES-{len(k)*8}-{mname} iv={ivn} data={dtag}", pt))
                except Exception: pass
        if len(iv) == 16:
            try:
                pt = AES.new(k, AES.MODE_ECB).decrypt(CT)
                if hits(pt): found.append((f"{kn} AES-ECB", pt))
            except Exception: pass
        if len(k) == 24:
            try:
                pt = DES3.new(k, DES3.MODE_CBC, iv=iv[:8]).decrypt(CT[:56])
                if hits(pt): found.append((f"{kn} 3DES-CBC iv={ivn[:8]}", pt))
            except Exception: pass
    try:
        pt = ARC4.new(k).decrypt(CT)
        if hits(pt): found.append((f"{kn} RC4", pt))
    except Exception: pass

print(f"[*] {len(keys)} keys x {len(ivs)} ivs tested")
for d, pt in found:
    print("!!! ", d, "=>", pt[:80])
if not found:
    print("[-] no direct hit; entropy check: CT unique bytes =", len(set(CT)))
    # dump top printable for eyeballing
