/* CSG2026 Blueprint site.js — copy buttons, search. No fetch(), file:// safe. */
document.addEventListener('DOMContentLoaded', function () {
  // copy buttons on pre blocks
  document.querySelectorAll('pre').forEach(function (pre) {
    var btn = document.createElement('button');
    btn.className = 'copybtn';
    btn.textContent = 'COPY';
    btn.addEventListener('click', function () {
      var txt = pre.innerText.replace(/^COPY\n/, '');
      function done() { btn.textContent = 'COPIED ✓'; setTimeout(function () { btn.textContent = 'COPY'; }, 1200); }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(done, function () { fallback(); });
      } else { fallback(); }
      function fallback() {
        var ta = document.createElement('textarea');
        ta.value = txt; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        document.body.removeChild(ta);
      }
    });
    pre.appendChild(btn);
  });
});
