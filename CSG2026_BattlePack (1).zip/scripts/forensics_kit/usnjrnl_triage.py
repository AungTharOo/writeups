#!/usr/bin/env python3
"""
usnjrnl_triage.py - parse NTFS $Extend/$J (UsnJrnl:2) stream for CTF triage.
Works on the raw extracted $J file (sparse runs handled by scanning).

Modes:
  --name flag|txt|exe    substring filename filter (case-insensitive)
  --rec 252219           events for MFT reference
  --time "2025-09-10 08:18:20" ± window (UTC)
  --reason               aggregate reason counters
"""
import struct, argparse, datetime, mmap, sys

EPOCH = datetime.datetime(1601, 1, 1)

def ft(f):
    if f == 0:
        return None
    try:
        return EPOCH + datetime.timedelta(microseconds=f // 10)
    except OverflowError:
        return None

REASONS = [
    (0x00000001, "DATA_OVERWRITE"), (0x00000002, "DATA_EXTEND"), (0x00000004, "DATA_TRUNCATION"),
    (0x00000010, "NAMED_DATA_OVERWRITE"), (0x00000020, "NAMED_DATA_EXTEND"), (0x00000040, "NAMED_DATA_TRUNCATION"),
    (0x00000100, "FILE_CREATE"), (0x00000200, "FILE_DELETE"), (0x00000400, "EA_CHANGE"),
    (0x00000800, "SECURITY_CHANGE"), (0x00001000, "RENAME_OLD_NAME"), (0x00002000, "RENAME_NEW_NAME"),
    (0x00004000, "INDEXABLE_CHANGE"), (0x00008000, "BASIC_INFO_CHANGE"), (0x00010000, "HARD_LINK_CHANGE"),
    (0x00020000, "COMPRESSION_CHANGE"), (0x00040000, "ENCRYPTION_CHANGE"), (0x00080000, "OBJECT_ID_CHANGE"),
    (0x00100000, "REPARSE_POINT_CHANGE"), (0x00200000, "STREAM_CHANGE"), (0x00400000, "TRANSACTED_CHANGE"),
    (0x00800000, "INTEGRITY_CHANGE"), (0x80000000, "CLOSE"),
]

def reason_str(r):
    return "|".join(n for v, n in REASONS if r & v) or hex(r)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("jfile")
    ap.add_argument("--name")
    ap.add_argument("--rec", type=lambda x: int(x, 0))
    ap.add_argument("--time")
    ap.add_argument("--window", type=float, default=60)
    ap.add_argument("--reason", action="store_true")
    ap.add_argument("--limit", type=int, default=400)
    args = ap.parse_args()

    f = open(args.jfile, "rb")
    mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)

    targets = None
    if args.time:
        dt = None
        for fmt in ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"):
            try:
                dt = datetime.datetime.strptime(args.time, fmt)
                break
            except ValueError:
                pass
        if dt is None:
            sys.exit("bad time")
        targets = dt

    counts = {}
    n = 0
    shown = 0
    pos = 0
    size = mm.size()
    while pos < size - 8:
        # skip zero runs
        if mm[pos] == 0:
            # scan forward for a plausible USN record header (8-byte aligned)
            found = -1
            q = (pos + 7) & ~7
            limit = min(size - 64, pos + (64 << 20))
            while q < limit:
                if mm[q] != 0:
                    rlen_try = struct.unpack_from("<I", mm, q)[0]
                    if 60 <= rlen_try <= 0x1000 and (q + rlen_try) <= size:
                        maj_try, mino_try = struct.unpack_from("<HH", mm, q + 4)
                        if maj_try in (2, 3, 4) and mino_try in (0, 1, 2):
                            found = q
                            break
                    q += 8
                else:
                    q += 8
            if found < 0:
                break
            pos = found
        try:
            rlen, maj, mino = struct.unpack_from("<IHH", mm, pos)
        except struct.error:
            break
        if rlen < 60 or rlen > 0x1000 or maj not in (2, 3, 4):
            pos += 1
            continue
        n += 1
        if maj == 2:
            fileref, parent, usn = struct.unpack_from("<QQQ", mm, pos + 8)
            ts, reason, srcinfo, secid, attrs = struct.unpack_from("<QIIII", mm, pos + 32)
            nlen = struct.unpack_from("<H", mm, pos + 56)[0]
            noff = struct.unpack_from("<H", mm, pos + 58)[0]
        else:
            # v3/v4: 24-byte file refs
            fileref, parent, usn = struct.unpack_from("<QQQ", mm, pos + 24)
            ts, reason, srcinfo, secid, attrs = struct.unpack_from("<QIIII", mm, pos + 48)
            nlen = struct.unpack_from("<H", mm, pos + 72)[0]
            noff = struct.unpack_from("<H", mm, pos + 74)[0]
        name = ""
        if 0 < nlen < 300 and noff > 0:
            raw = mm[pos + noff: pos + noff + nlen * 2]
            if len(raw) == nlen * 2:
                name = raw.decode("utf-16-le", "replace")
        counts[reason] = counts.get(reason, 0) + 1

        show = False
        if args.name and args.name.lower() in name.lower():
            show = True
        if args.rec is not None and ((fileref & 0xFFFFFFFFFFFF) == args.rec or (parent & 0xFFFFFFFFFFFF) == args.rec):
            show = True
        if targets is not None:
            t = ft(ts)
            if t and abs((t - targets).total_seconds()) <= args.window:
                show = True
        if show:
            t = ft(ts)
            print(f"usn={usn} ts={t} rec={fileref & 0xFFFFFFFFFFFF} parent={parent & 0xFFFFFFFFFFFF} "
                  f"name={name!r} reason={reason_str(reason)}")
            shown += 1
            if shown >= args.limit:
                break
        pos += rlen
    if args.reason:
        print("\n== reason counts ==")
        for r, c in sorted(counts.items(), key=lambda x: -x[1]):
            print(f"  {reason_str(r)}: {c}")
    sys.stderr.write(f"[i] parsed {n} USN records\n")

if __name__ == "__main__":
    main()
